gdjs.NivelCode = {};
gdjs.NivelCode.localVariables = [];
gdjs.NivelCode.idToCallbackMap = new Map();
gdjs.NivelCode.GDCURIQUINGUEObjects1_1final = [];

gdjs.NivelCode.GDHUMAObjects1_1final = [];

gdjs.NivelCode.GDLATAObjects1_1final = [];

gdjs.NivelCode.GDPuruObjects1_1final = [];

gdjs.NivelCode.GDSamiObjects1_1final = [];

gdjs.NivelCode.GDenemy1Objects1_1final = [];

gdjs.NivelCode.GDenemy2Objects1_1final = [];

gdjs.NivelCode.GDenemy3Objects1_1final = [];

gdjs.NivelCode.forEachCount0_2 = 0;

gdjs.NivelCode.forEachCount1_2 = 0;

gdjs.NivelCode.forEachCount2_2 = 0;

gdjs.NivelCode.forEachCount3_2 = 0;

gdjs.NivelCode.forEachIndex2 = 0;

gdjs.NivelCode.forEachObjects2 = [];

gdjs.NivelCode.forEachTemporary2 = null;

gdjs.NivelCode.forEachTotalCount2 = 0;

gdjs.NivelCode.GDM_95225scara_9595HumaObjects1= [];
gdjs.NivelCode.GDM_95225scara_9595HumaObjects2= [];
gdjs.NivelCode.GDM_95225scara_9595HumaObjects3= [];
gdjs.NivelCode.GDM_95225scara_9595HumaObjects4= [];
gdjs.NivelCode.GDbackgroundObjects1= [];
gdjs.NivelCode.GDbackgroundObjects2= [];
gdjs.NivelCode.GDbackgroundObjects3= [];
gdjs.NivelCode.GDbackgroundObjects4= [];
gdjs.NivelCode.GDNewSpriteObjects1= [];
gdjs.NivelCode.GDNewSpriteObjects2= [];
gdjs.NivelCode.GDNewSpriteObjects3= [];
gdjs.NivelCode.GDNewSpriteObjects4= [];
gdjs.NivelCode.GDM_95225scara_9595LataObjects1= [];
gdjs.NivelCode.GDM_95225scara_9595LataObjects2= [];
gdjs.NivelCode.GDM_95225scara_9595LataObjects3= [];
gdjs.NivelCode.GDM_95225scara_9595LataObjects4= [];
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects1= [];
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2= [];
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects3= [];
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects4= [];
gdjs.NivelCode.GDSamiObjects1= [];
gdjs.NivelCode.GDSamiObjects2= [];
gdjs.NivelCode.GDSamiObjects3= [];
gdjs.NivelCode.GDSamiObjects4= [];
gdjs.NivelCode.GDNewTiledSpriteObjects1= [];
gdjs.NivelCode.GDNewTiledSpriteObjects2= [];
gdjs.NivelCode.GDNewTiledSpriteObjects3= [];
gdjs.NivelCode.GDNewTiledSpriteObjects4= [];
gdjs.NivelCode.GDVida_95951Objects1= [];
gdjs.NivelCode.GDVida_95951Objects2= [];
gdjs.NivelCode.GDVida_95951Objects3= [];
gdjs.NivelCode.GDVida_95951Objects4= [];
gdjs.NivelCode.GDNewTiledSprite2Objects1= [];
gdjs.NivelCode.GDNewTiledSprite2Objects2= [];
gdjs.NivelCode.GDNewTiledSprite2Objects3= [];
gdjs.NivelCode.GDNewTiledSprite2Objects4= [];
gdjs.NivelCode.GDNewTiledSprite3Objects1= [];
gdjs.NivelCode.GDNewTiledSprite3Objects2= [];
gdjs.NivelCode.GDNewTiledSprite3Objects3= [];
gdjs.NivelCode.GDNewTiledSprite3Objects4= [];
gdjs.NivelCode.GDNewTiledSprite4Objects1= [];
gdjs.NivelCode.GDNewTiledSprite4Objects2= [];
gdjs.NivelCode.GDNewTiledSprite4Objects3= [];
gdjs.NivelCode.GDNewTiledSprite4Objects4= [];
gdjs.NivelCode.GDenemy1Objects1= [];
gdjs.NivelCode.GDenemy1Objects2= [];
gdjs.NivelCode.GDenemy1Objects3= [];
gdjs.NivelCode.GDenemy1Objects4= [];
gdjs.NivelCode.GDVida_95952Objects1= [];
gdjs.NivelCode.GDVida_95952Objects2= [];
gdjs.NivelCode.GDVida_95952Objects3= [];
gdjs.NivelCode.GDVida_95952Objects4= [];
gdjs.NivelCode.GDVida_95953Objects1= [];
gdjs.NivelCode.GDVida_95953Objects2= [];
gdjs.NivelCode.GDVida_95953Objects3= [];
gdjs.NivelCode.GDVida_95953Objects4= [];
gdjs.NivelCode.GDVida_95954Objects1= [];
gdjs.NivelCode.GDVida_95954Objects2= [];
gdjs.NivelCode.GDVida_95954Objects3= [];
gdjs.NivelCode.GDVida_95954Objects4= [];
gdjs.NivelCode.GDVida_95955Objects1= [];
gdjs.NivelCode.GDVida_95955Objects2= [];
gdjs.NivelCode.GDVida_95955Objects3= [];
gdjs.NivelCode.GDVida_95955Objects4= [];
gdjs.NivelCode.GDHUMAObjects1= [];
gdjs.NivelCode.GDHUMAObjects2= [];
gdjs.NivelCode.GDHUMAObjects3= [];
gdjs.NivelCode.GDHUMAObjects4= [];
gdjs.NivelCode.GDLATAObjects1= [];
gdjs.NivelCode.GDLATAObjects2= [];
gdjs.NivelCode.GDLATAObjects3= [];
gdjs.NivelCode.GDLATAObjects4= [];
gdjs.NivelCode.GDCURIQUINGUEObjects1= [];
gdjs.NivelCode.GDCURIQUINGUEObjects2= [];
gdjs.NivelCode.GDCURIQUINGUEObjects3= [];
gdjs.NivelCode.GDCURIQUINGUEObjects4= [];
gdjs.NivelCode.GDenemy2Objects1= [];
gdjs.NivelCode.GDenemy2Objects2= [];
gdjs.NivelCode.GDenemy2Objects3= [];
gdjs.NivelCode.GDenemy2Objects4= [];
gdjs.NivelCode.GDenemy3Objects1= [];
gdjs.NivelCode.GDenemy3Objects2= [];
gdjs.NivelCode.GDenemy3Objects3= [];
gdjs.NivelCode.GDenemy3Objects4= [];
gdjs.NivelCode.GDPuruObjects1= [];
gdjs.NivelCode.GDPuruObjects2= [];
gdjs.NivelCode.GDPuruObjects3= [];
gdjs.NivelCode.GDPuruObjects4= [];
gdjs.NivelCode.GDpinchosObjects1= [];
gdjs.NivelCode.GDpinchosObjects2= [];
gdjs.NivelCode.GDpinchosObjects3= [];
gdjs.NivelCode.GDpinchosObjects4= [];
gdjs.NivelCode.GDproyectilObjects1= [];
gdjs.NivelCode.GDproyectilObjects2= [];
gdjs.NivelCode.GDproyectilObjects3= [];
gdjs.NivelCode.GDproyectilObjects4= [];
gdjs.NivelCode.GDHitParticlesObjects1= [];
gdjs.NivelCode.GDHitParticlesObjects2= [];
gdjs.NivelCode.GDHitParticlesObjects3= [];
gdjs.NivelCode.GDHitParticlesObjects4= [];
gdjs.NivelCode.GDhumanoObjects1= [];
gdjs.NivelCode.GDhumanoObjects2= [];
gdjs.NivelCode.GDhumanoObjects3= [];
gdjs.NivelCode.GDhumanoObjects4= [];
gdjs.NivelCode.GDbarreraObjects1= [];
gdjs.NivelCode.GDbarreraObjects2= [];
gdjs.NivelCode.GDbarreraObjects3= [];
gdjs.NivelCode.GDbarreraObjects4= [];
gdjs.NivelCode.GDNewSprite2Objects1= [];
gdjs.NivelCode.GDNewSprite2Objects2= [];
gdjs.NivelCode.GDNewSprite2Objects3= [];
gdjs.NivelCode.GDNewSprite2Objects4= [];
gdjs.NivelCode.GDNewSprite3Objects1= [];
gdjs.NivelCode.GDNewSprite3Objects2= [];
gdjs.NivelCode.GDNewSprite3Objects3= [];
gdjs.NivelCode.GDNewSprite3Objects4= [];
gdjs.NivelCode.GDNewSprite4Objects1= [];
gdjs.NivelCode.GDNewSprite4Objects2= [];
gdjs.NivelCode.GDNewSprite4Objects3= [];
gdjs.NivelCode.GDNewSprite4Objects4= [];
gdjs.NivelCode.GDNewSprite5Objects1= [];
gdjs.NivelCode.GDNewSprite5Objects2= [];
gdjs.NivelCode.GDNewSprite5Objects3= [];
gdjs.NivelCode.GDNewSprite5Objects4= [];
gdjs.NivelCode.GDNewSprite6Objects1= [];
gdjs.NivelCode.GDNewSprite6Objects2= [];
gdjs.NivelCode.GDNewSprite6Objects3= [];
gdjs.NivelCode.GDNewSprite6Objects4= [];
gdjs.NivelCode.GDNewSprite7Objects1= [];
gdjs.NivelCode.GDNewSprite7Objects2= [];
gdjs.NivelCode.GDNewSprite7Objects3= [];
gdjs.NivelCode.GDNewSprite7Objects4= [];
gdjs.NivelCode.GDNewSprite8Objects1= [];
gdjs.NivelCode.GDNewSprite8Objects2= [];
gdjs.NivelCode.GDNewSprite8Objects3= [];
gdjs.NivelCode.GDNewSprite8Objects4= [];
gdjs.NivelCode.GDNewSprite9Objects1= [];
gdjs.NivelCode.GDNewSprite9Objects2= [];
gdjs.NivelCode.GDNewSprite9Objects3= [];
gdjs.NivelCode.GDNewSprite9Objects4= [];
gdjs.NivelCode.GDNewSprite10Objects1= [];
gdjs.NivelCode.GDNewSprite10Objects2= [];
gdjs.NivelCode.GDNewSprite10Objects3= [];
gdjs.NivelCode.GDNewSprite10Objects4= [];
gdjs.NivelCode.GDNewSprite11Objects1= [];
gdjs.NivelCode.GDNewSprite11Objects2= [];
gdjs.NivelCode.GDNewSprite11Objects3= [];
gdjs.NivelCode.GDNewSprite11Objects4= [];
gdjs.NivelCode.GDNewSprite12Objects1= [];
gdjs.NivelCode.GDNewSprite12Objects2= [];
gdjs.NivelCode.GDNewSprite12Objects3= [];
gdjs.NivelCode.GDNewSprite12Objects4= [];
gdjs.NivelCode.GDNewSprite13Objects1= [];
gdjs.NivelCode.GDNewSprite13Objects2= [];
gdjs.NivelCode.GDNewSprite13Objects3= [];
gdjs.NivelCode.GDNewSprite13Objects4= [];
gdjs.NivelCode.GDNewSprite14Objects1= [];
gdjs.NivelCode.GDNewSprite14Objects2= [];
gdjs.NivelCode.GDNewSprite14Objects3= [];
gdjs.NivelCode.GDNewSprite14Objects4= [];
gdjs.NivelCode.GDNewTiledSprite6Objects1= [];
gdjs.NivelCode.GDNewTiledSprite6Objects2= [];
gdjs.NivelCode.GDNewTiledSprite6Objects3= [];
gdjs.NivelCode.GDNewTiledSprite6Objects4= [];
gdjs.NivelCode.GDNewSprite15Objects1= [];
gdjs.NivelCode.GDNewSprite15Objects2= [];
gdjs.NivelCode.GDNewSprite15Objects3= [];
gdjs.NivelCode.GDNewSprite15Objects4= [];
gdjs.NivelCode.GDNewSprite16Objects1= [];
gdjs.NivelCode.GDNewSprite16Objects2= [];
gdjs.NivelCode.GDNewSprite16Objects3= [];
gdjs.NivelCode.GDNewSprite16Objects4= [];
gdjs.NivelCode.GDNewSprite17Objects1= [];
gdjs.NivelCode.GDNewSprite17Objects2= [];
gdjs.NivelCode.GDNewSprite17Objects3= [];
gdjs.NivelCode.GDNewSprite17Objects4= [];
gdjs.NivelCode.GDNewSprite18Objects1= [];
gdjs.NivelCode.GDNewSprite18Objects2= [];
gdjs.NivelCode.GDNewSprite18Objects3= [];
gdjs.NivelCode.GDNewSprite18Objects4= [];
gdjs.NivelCode.GDNewTiledSprite7Objects1= [];
gdjs.NivelCode.GDNewTiledSprite7Objects2= [];
gdjs.NivelCode.GDNewTiledSprite7Objects3= [];
gdjs.NivelCode.GDNewTiledSprite7Objects4= [];
gdjs.NivelCode.GDNewSprite19Objects1= [];
gdjs.NivelCode.GDNewSprite19Objects2= [];
gdjs.NivelCode.GDNewSprite19Objects3= [];
gdjs.NivelCode.GDNewSprite19Objects4= [];
gdjs.NivelCode.GDNewSprite20Objects1= [];
gdjs.NivelCode.GDNewSprite20Objects2= [];
gdjs.NivelCode.GDNewSprite20Objects3= [];
gdjs.NivelCode.GDNewSprite20Objects4= [];
gdjs.NivelCode.GDproyectil_9595jugadorObjects1= [];
gdjs.NivelCode.GDproyectil_9595jugadorObjects2= [];
gdjs.NivelCode.GDproyectil_9595jugadorObjects3= [];
gdjs.NivelCode.GDproyectil_9595jugadorObjects4= [];
gdjs.NivelCode.GDbase1Objects1= [];
gdjs.NivelCode.GDbase1Objects2= [];
gdjs.NivelCode.GDbase1Objects3= [];
gdjs.NivelCode.GDbase1Objects4= [];
gdjs.NivelCode.GDNewTiledSprite5Objects1= [];
gdjs.NivelCode.GDNewTiledSprite5Objects2= [];
gdjs.NivelCode.GDNewTiledSprite5Objects3= [];
gdjs.NivelCode.GDNewTiledSprite5Objects4= [];
gdjs.NivelCode.GDNewTiledSprite8Objects1= [];
gdjs.NivelCode.GDNewTiledSprite8Objects2= [];
gdjs.NivelCode.GDNewTiledSprite8Objects3= [];
gdjs.NivelCode.GDNewTiledSprite8Objects4= [];
gdjs.NivelCode.GDpiedrasoObjects1= [];
gdjs.NivelCode.GDpiedrasoObjects2= [];
gdjs.NivelCode.GDpiedrasoObjects3= [];
gdjs.NivelCode.GDpiedrasoObjects4= [];
gdjs.NivelCode.GDpiedraObjects1= [];
gdjs.NivelCode.GDpiedraObjects2= [];
gdjs.NivelCode.GDpiedraObjects3= [];
gdjs.NivelCode.GDpiedraObjects4= [];
gdjs.NivelCode.GDcheckObjects1= [];
gdjs.NivelCode.GDcheckObjects2= [];
gdjs.NivelCode.GDcheckObjects3= [];
gdjs.NivelCode.GDcheckObjects4= [];
gdjs.NivelCode.GDTrofeoObjects1= [];
gdjs.NivelCode.GDTrofeoObjects2= [];
gdjs.NivelCode.GDTrofeoObjects3= [];
gdjs.NivelCode.GDTrofeoObjects4= [];
gdjs.NivelCode.GDMobileJoystickObjects1= [];
gdjs.NivelCode.GDMobileJoystickObjects2= [];
gdjs.NivelCode.GDMobileJoystickObjects3= [];
gdjs.NivelCode.GDMobileJoystickObjects4= [];
gdjs.NivelCode.GDJumpButtonObjects1= [];
gdjs.NivelCode.GDJumpButtonObjects2= [];
gdjs.NivelCode.GDJumpButtonObjects3= [];
gdjs.NivelCode.GDJumpButtonObjects4= [];
gdjs.NivelCode.GDinicioObjects1= [];
gdjs.NivelCode.GDinicioObjects2= [];
gdjs.NivelCode.GDinicioObjects3= [];
gdjs.NivelCode.GDinicioObjects4= [];
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects1= [];
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects2= [];
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects3= [];
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects4= [];
gdjs.NivelCode.GDNewSprite21Objects1= [];
gdjs.NivelCode.GDNewSprite21Objects2= [];
gdjs.NivelCode.GDNewSprite21Objects3= [];
gdjs.NivelCode.GDNewSprite21Objects4= [];
gdjs.NivelCode.GDflecahasObjects1= [];
gdjs.NivelCode.GDflecahasObjects2= [];
gdjs.NivelCode.GDflecahasObjects3= [];
gdjs.NivelCode.GDflecahasObjects4= [];
gdjs.NivelCode.GDspaceObjects1= [];
gdjs.NivelCode.GDspaceObjects2= [];
gdjs.NivelCode.GDspaceObjects3= [];
gdjs.NivelCode.GDspaceObjects4= [];
gdjs.NivelCode.GDLetra_9595QObjects1= [];
gdjs.NivelCode.GDLetra_9595QObjects2= [];
gdjs.NivelCode.GDLetra_9595QObjects3= [];
gdjs.NivelCode.GDLetra_9595QObjects4= [];
gdjs.NivelCode.GDNewSprite22Objects1= [];
gdjs.NivelCode.GDNewSprite22Objects2= [];
gdjs.NivelCode.GDNewSprite22Objects3= [];
gdjs.NivelCode.GDNewSprite22Objects4= [];
gdjs.NivelCode.GDcuriquingue_9595letrasObjects1= [];
gdjs.NivelCode.GDcuriquingue_9595letrasObjects2= [];
gdjs.NivelCode.GDcuriquingue_9595letrasObjects3= [];
gdjs.NivelCode.GDcuriquingue_9595letrasObjects4= [];
gdjs.NivelCode.GDHaya_9595humaObjects1= [];
gdjs.NivelCode.GDHaya_9595humaObjects2= [];
gdjs.NivelCode.GDHaya_9595humaObjects3= [];
gdjs.NivelCode.GDHaya_9595humaObjects4= [];


gdjs.NivelCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) * 0.90, "Background04", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) * 0.75, "Background03", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) * 0.50, "Background02", 0);
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) * 0.25, "Background01", 0);
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595HumaObjects2Objects = Hashtable.newFrom({"Máscara_Huma": gdjs.NivelCode.GDM_95225scara_9595HumaObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects = Hashtable.newFrom({"HUMA": gdjs.NivelCode.GDHUMAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects = Hashtable.newFrom({"HUMA": gdjs.NivelCode.GDHUMAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595LataObjects2Objects = Hashtable.newFrom({"Máscara_Lata": gdjs.NivelCode.GDM_95225scara_9595LataObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects = Hashtable.newFrom({"LATA": gdjs.NivelCode.GDLATAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects = Hashtable.newFrom({"HUMA": gdjs.NivelCode.GDHUMAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595CuriquingueObjects2Objects = Hashtable.newFrom({"Máscara_Curiquingue": gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects1Objects = Hashtable.newFrom({"HUMA": gdjs.NivelCode.GDHUMAObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDhumanoObjects1Objects = Hashtable.newFrom({"humano": gdjs.NivelCode.GDhumanoObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1});
gdjs.NivelCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects2[k] = gdjs.NivelCode.GDHUMAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("Animation").setAnimationName("caminar huma");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects2.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects2[k] = gdjs.NivelCode.GDHUMAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("Animation").setAnimationName("descanzo huma");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects2[k] = gdjs.NivelCode.GDHUMAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects2[k] = gdjs.NivelCode.GDHUMAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects2[k] = gdjs.NivelCode.GDHUMAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("Animation").setAnimationName("salto y caida huma");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].setAnimationFrame(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects2[k] = gdjs.NivelCode.GDHUMAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("Animation").setAnimationName("salto y caida huma");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].setAnimationFrame(1);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.NivelCode.GDHUMAObjects2.length !== 0 ? gdjs.NivelCode.GDHUMAObjects2[0] : null), true, "", 0);
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Máscara_Huma"), gdjs.NivelCode.GDM_95225scara_9595HumaObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595HumaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDM_95225scara_9595HumaObjects2 */
/* Reuse gdjs.NivelCode.GDSamiObjects2 */
gdjs.NivelCode.GDHUMAObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects, (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointX("")), (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595HumaObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595HumaObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Máscara_Lata"), gdjs.NivelCode.GDM_95225scara_9595LataObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595LataObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
/* Reuse gdjs.NivelCode.GDM_95225scara_9595LataObjects2 */
gdjs.NivelCode.GDLATAObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects, (( gdjs.NivelCode.GDHUMAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects2[0].getPointX("")), (( gdjs.NivelCode.GDHUMAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595LataObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595LataObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Máscara_Curiquingue"), gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595CuriquingueObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Máscara_Lata"), gdjs.NivelCode.GDM_95225scara_9595LataObjects2);
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, (( gdjs.NivelCode.GDHUMAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects2[0].getPointX("")), (( gdjs.NivelCode.GDHUMAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595LataObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595LataObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("humano"), gdjs.NivelCode.GDhumanoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDhumanoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects1 */
gdjs.NivelCode.GDSamiObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1Objects, (( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects1[0].getPointX("")), (( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects1[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595LataObjects2Objects = Hashtable.newFrom({"Máscara_Lata": gdjs.NivelCode.GDM_95225scara_9595LataObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects = Hashtable.newFrom({"LATA": gdjs.NivelCode.GDLATAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects = Hashtable.newFrom({"LATA": gdjs.NivelCode.GDLATAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595HumaObjects2Objects = Hashtable.newFrom({"Máscara_Huma": gdjs.NivelCode.GDM_95225scara_9595HumaObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects = Hashtable.newFrom({"HUMA": gdjs.NivelCode.GDHUMAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects = Hashtable.newFrom({"LATA": gdjs.NivelCode.GDLATAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595CuriquingueObjects2Objects = Hashtable.newFrom({"Máscara_Curiquingue": gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects1Objects = Hashtable.newFrom({"LATA": gdjs.NivelCode.GDLATAObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDhumanoObjects1Objects = Hashtable.newFrom({"humano": gdjs.NivelCode.GDhumanoObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1});
gdjs.NivelCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects2[k] = gdjs.NivelCode.GDLATAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("Animation").setAnimationName("caminar lata");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects2.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects2[k] = gdjs.NivelCode.GDLATAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("Animation").setAnimationName("descanzo lata");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects2[k] = gdjs.NivelCode.GDLATAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects2[k] = gdjs.NivelCode.GDLATAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.NivelCode.GDLATAObjects2.length !== 0 ? gdjs.NivelCode.GDLATAObjects2[0] : null), true, "", 0);
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects2[k] = gdjs.NivelCode.GDLATAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("Animation").setAnimationName("salto caida ");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].setAnimationFrame(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects2[k] = gdjs.NivelCode.GDLATAObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("Animation").setAnimationName("salto caida ");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].setAnimationFrame(1);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Máscara_Lata"), gdjs.NivelCode.GDM_95225scara_9595LataObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595LataObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDM_95225scara_9595LataObjects2 */
/* Reuse gdjs.NivelCode.GDSamiObjects2 */
gdjs.NivelCode.GDLATAObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects, (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointX("")), (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595LataObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595LataObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Máscara_Huma"), gdjs.NivelCode.GDM_95225scara_9595HumaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595HumaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Máscara_Lata"), gdjs.NivelCode.GDM_95225scara_9595LataObjects2);
gdjs.NivelCode.GDHUMAObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects, (( gdjs.NivelCode.GDLATAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDLATAObjects2[0].getPointX("")), (( gdjs.NivelCode.GDLATAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDLATAObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595LataObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595LataObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Máscara_Curiquingue"), gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595CuriquingueObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Máscara_Lata"), gdjs.NivelCode.GDM_95225scara_9595LataObjects2);
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, (( gdjs.NivelCode.GDLATAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDLATAObjects2[0].getPointX("")), (( gdjs.NivelCode.GDLATAObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDLATAObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595LataObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595LataObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("humano"), gdjs.NivelCode.GDhumanoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDhumanoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
gdjs.NivelCode.GDSamiObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1Objects, (( gdjs.NivelCode.GDLATAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDLATAObjects1[0].getPointX("")), (( gdjs.NivelCode.GDLATAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDLATAObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595CuriquingueObjects2Objects = Hashtable.newFrom({"Máscara_Curiquingue": gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595HumaObjects2Objects = Hashtable.newFrom({"Máscara_Huma": gdjs.NivelCode.GDM_95225scara_9595HumaObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects = Hashtable.newFrom({"HUMA": gdjs.NivelCode.GDHUMAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595LataObjects2Objects = Hashtable.newFrom({"Máscara_Lata": gdjs.NivelCode.GDM_95225scara_9595LataObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects = Hashtable.newFrom({"LATA": gdjs.NivelCode.GDLATAObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects = Hashtable.newFrom({"CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDhumanoObjects1Objects = Hashtable.newFrom({"humano": gdjs.NivelCode.GDhumanoObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1});
gdjs.NivelCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Máscara_Curiquingue"), gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595CuriquingueObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2 */
/* Reuse gdjs.NivelCode.GDSamiObjects2 */
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointX("")), (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects2[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects2[k] = gdjs.NivelCode.GDCURIQUINGUEObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("Animation").setAnimationName("caminar curi");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects2.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects2[k] = gdjs.NivelCode.GDCURIQUINGUEObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("Animation").setAnimationName("descanzo curi");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects2[k] = gdjs.NivelCode.GDCURIQUINGUEObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects2[k] = gdjs.NivelCode.GDCURIQUINGUEObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.NivelCode.GDCURIQUINGUEObjects2.length !== 0 ? gdjs.NivelCode.GDCURIQUINGUEObjects2[0] : null), true, "", 0);
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects2[k] = gdjs.NivelCode.GDCURIQUINGUEObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("Animation").setAnimationName("salto caida");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].setAnimationFrame(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects2[k] = gdjs.NivelCode.GDCURIQUINGUEObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("Animation").setAnimationName("salto caida");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].setAnimationFrame(1);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Máscara_Huma"), gdjs.NivelCode.GDM_95225scara_9595HumaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595HumaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
/* Reuse gdjs.NivelCode.GDM_95225scara_9595HumaObjects2 */
gdjs.NivelCode.GDHUMAObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHUMAObjects2Objects, (( gdjs.NivelCode.GDCURIQUINGUEObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDCURIQUINGUEObjects2[0].getPointX("")), (( gdjs.NivelCode.GDCURIQUINGUEObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDCURIQUINGUEObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDM_95225scara_9595HumaObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDM_95225scara_9595HumaObjects2[i].hide(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Máscara_Lata"), gdjs.NivelCode.GDM_95225scara_9595LataObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDM_959595225scara_95959595LataObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects2 */
gdjs.NivelCode.GDLATAObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDLATAObjects2Objects, (( gdjs.NivelCode.GDCURIQUINGUEObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDCURIQUINGUEObjects2[0].getPointX("")), (( gdjs.NivelCode.GDCURIQUINGUEObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDCURIQUINGUEObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].hide(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("humano"), gdjs.NivelCode.GDhumanoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDhumanoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
gdjs.NivelCode.GDSamiObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1Objects, (( gdjs.NivelCode.GDCURIQUINGUEObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDCURIQUINGUEObjects1[0].getPointX("")), (( gdjs.NivelCode.GDCURIQUINGUEObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDCURIQUINGUEObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.eventsList4 = function(runtimeScene) {

};gdjs.NivelCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.NivelCode.GDenemy3Objects1 */

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy3Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDenemy3Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy3Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy3Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects2[i].returnVariable(gdjs.NivelCode.GDenemy3Objects2[i].getVariables().getFromIndex(0)).setNumber(3);
}
}
}
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy1Objects2Objects = Hashtable.newFrom({"enemy1": gdjs.NivelCode.GDenemy1Objects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy2Objects2Objects = Hashtable.newFrom({"enemy2": gdjs.NivelCode.GDenemy2Objects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects2Objects = Hashtable.newFrom({"enemy3": gdjs.NivelCode.GDenemy3Objects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDPuruObjects2Objects = Hashtable.newFrom({"Puru": gdjs.NivelCode.GDPuruObjects2});
gdjs.NivelCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 4);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_1"), gdjs.NivelCode.GDVida_95951Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95951Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95951Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_2"), gdjs.NivelCode.GDVida_95952Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95952Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95952Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_3"), gdjs.NivelCode.GDVida_95953Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95953Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95953Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_4"), gdjs.NivelCode.GDVida_95954Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95954Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95954Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_5"), gdjs.NivelCode.GDVida_95955Objects1);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95955Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95955Objects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1, "HUMA": gdjs.NivelCode.GDHUMAObjects1, "LATA": gdjs.NivelCode.GDLATAObjects1, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDpinchosObjects1Objects = Hashtable.newFrom({"pinchos": gdjs.NivelCode.GDpinchosObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects3, "HUMA": gdjs.NivelCode.GDHUMAObjects3, "LATA": gdjs.NivelCode.GDLATAObjects3, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects3});
gdjs.NivelCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects3);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects3);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects3);
gdjs.copyArray(gdjs.NivelCode.GDenemy1Objects2, gdjs.NivelCode.GDenemy1Objects3);

{gdjs.evtTools.object.pickNearestObject(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects, (( gdjs.NivelCode.GDenemy1Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy1Objects3[0].getCenterXInScene()), (( gdjs.NivelCode.GDenemy1Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy1Objects3[0].getCenterYInScene()));
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects3);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects3);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects3);
gdjs.copyArray(gdjs.NivelCode.GDenemy1Objects2, gdjs.NivelCode.GDenemy1Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDHUMAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDLATAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getCenterXInScene()) < (( gdjs.NivelCode.GDenemy1Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy1Objects3[0].getCenterXInScene()));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy1Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy1Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy1Objects3[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects3);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects3);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects3);
gdjs.copyArray(gdjs.NivelCode.GDenemy1Objects2, gdjs.NivelCode.GDenemy1Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDHUMAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDLATAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getCenterXInScene()) < (( gdjs.NivelCode.GDenemy1Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy1Objects3[0].getCenterXInScene()));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy1Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy1Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy1Objects3[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.NivelCode.GDenemy2Objects2, gdjs.NivelCode.GDenemy2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDenemy2Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy2Objects3[0].getCenterXInScene()) > (gdjs.RuntimeObject.getVariableNumber(((gdjs.NivelCode.GDenemy2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.NivelCode.GDenemy2Objects3[0].getVariables()).getFromIndex(1))));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy2Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects3[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDenemy2Objects2, gdjs.NivelCode.GDenemy2Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDenemy2Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy2Objects3[0].getCenterXInScene()) < (gdjs.RuntimeObject.getVariableNumber(((gdjs.NivelCode.GDenemy2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.NivelCode.GDenemy2Objects3[0].getVariables()).getFromIndex(1))));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy2Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects3[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.NivelCode.GDenemy2Objects2, gdjs.NivelCode.GDenemy2Objects3);

{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects3[i].returnVariable(gdjs.NivelCode.GDenemy2Objects3[i].getVariables().getFromIndex(1)).setNumber((gdjs.NivelCode.GDenemy2Objects3[i].getCenterXInScene()));
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects3Objects = Hashtable.newFrom({"enemy3": gdjs.NivelCode.GDenemy3Objects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects3, "HUMA": gdjs.NivelCode.GDHUMAObjects3, "LATA": gdjs.NivelCode.GDLATAObjects3, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects3Objects = Hashtable.newFrom({"enemy3": gdjs.NivelCode.GDenemy3Objects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects3, "HUMA": gdjs.NivelCode.GDHUMAObjects3, "LATA": gdjs.NivelCode.GDLATAObjects3, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects3Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects3, "HUMA": gdjs.NivelCode.GDHUMAObjects3, "LATA": gdjs.NivelCode.GDLATAObjects3, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects3});
gdjs.NivelCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDHUMAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDLATAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getCenterXInScene()) < (( gdjs.NivelCode.GDenemy3Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects3[0].getCenterXInScene()));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDHUMAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDLATAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getCenterXInScene()) < (( gdjs.NivelCode.GDenemy3Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects3[0].getCenterXInScene()));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects3Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects, 200, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].returnVariable(gdjs.NivelCode.GDenemy3Objects3[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Animation").setAnimationName("ataque");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects3Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects, 200, true);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].returnVariable(gdjs.NivelCode.GDenemy3Objects3[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Animation").setAnimationName("descanso");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy3Objects3.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy3Objects3[i].getVariableNumber(gdjs.NivelCode.GDenemy3Objects3[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy3Objects3[k] = gdjs.NivelCode.GDenemy3Objects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy3Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);

/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
gdjs.NivelCode.GDproyectilObjects3.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("FireBullet").FireTowardObject((gdjs.NivelCode.GDenemy3Objects3[i].getCenterXInScene()), (gdjs.NivelCode.GDenemy3Objects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects3Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects, 300, null);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDenemy3Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects3[0].getDistanceToObject((gdjs.NivelCode.GDSamiObjects3.length !== 0 ? gdjs.NivelCode.GDSamiObjects3[0] : (gdjs.NivelCode.GDHUMAObjects3.length !== 0 ? gdjs.NivelCode.GDHUMAObjects3[0] : (gdjs.NivelCode.GDLATAObjects3.length !== 0 ? gdjs.NivelCode.GDLATAObjects3[0] : (gdjs.NivelCode.GDCURIQUINGUEObjects3.length !== 0 ? gdjs.NivelCode.GDCURIQUINGUEObjects3[0] : null)))))) <= 200);
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].returnVariable(gdjs.NivelCode.GDenemy3Objects3[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Animation").setAnimationName("ataque");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDenemy3Objects3.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects3[0].getDistanceToObject((gdjs.NivelCode.GDSamiObjects3.length !== 0 ? gdjs.NivelCode.GDSamiObjects3[0] : (gdjs.NivelCode.GDHUMAObjects3.length !== 0 ? gdjs.NivelCode.GDHUMAObjects3[0] : (gdjs.NivelCode.GDLATAObjects3.length !== 0 ? gdjs.NivelCode.GDLATAObjects3[0] : (gdjs.NivelCode.GDCURIQUINGUEObjects3.length !== 0 ? gdjs.NivelCode.GDCURIQUINGUEObjects3[0] : null)))))) > 200);
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].returnVariable(gdjs.NivelCode.GDenemy3Objects3[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Animation").setAnimationName("descanso");
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects3, "HUMA": gdjs.NivelCode.GDHUMAObjects3, "LATA": gdjs.NivelCode.GDLATAObjects3, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects3});
gdjs.NivelCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects3);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects3);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects3);
gdjs.copyArray(gdjs.NivelCode.GDPuruObjects2, gdjs.NivelCode.GDPuruObjects3);

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects3);
{gdjs.evtTools.object.pickNearestObject(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects3ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects3ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects3ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects3Objects, (( gdjs.NivelCode.GDPuruObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects3[0].getCenterXInScene()), (( gdjs.NivelCode.GDPuruObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects3[0].getCenterYInScene()));
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects3);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects3);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects3);
gdjs.copyArray(gdjs.NivelCode.GDPuruObjects2, gdjs.NivelCode.GDPuruObjects3);

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDHUMAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDLATAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getCenterXInScene()) < (( gdjs.NivelCode.GDPuruObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects3[0].getCenterXInScene()));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDPuruObjects3 */
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects3[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects3);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects3);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects3);
gdjs.copyArray(gdjs.NivelCode.GDPuruObjects2, gdjs.NivelCode.GDPuruObjects3);

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDHUMAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDLATAObjects3[0].getCenterXInScene()) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getCenterXInScene()) < (( gdjs.NivelCode.GDPuruObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects3[0].getCenterXInScene()));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDPuruObjects3 */
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects3[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects3Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects3Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects3});
gdjs.NivelCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy3Objects3.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Scale").getScaleX() >= 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy3Objects3[k] = gdjs.NivelCode.GDenemy3Objects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy3Objects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
gdjs.NivelCode.GDproyectilObjects3.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDenemy3Objects3[i].getCenterXInScene()), (gdjs.NivelCode.GDenemy3Objects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects3Objects, 0, 300, null);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects2, gdjs.NivelCode.GDenemy3Objects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy3Objects3.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("Scale").getScaleX() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy3Objects3[k] = gdjs.NivelCode.GDenemy3Objects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy3Objects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects3 */
gdjs.NivelCode.GDproyectilObjects3.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects3.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDenemy3Objects3[i].getCenterXInScene()), (gdjs.NivelCode.GDenemy3Objects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects3Objects, 180, 300, null);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects = Hashtable.newFrom({"barrera": gdjs.NivelCode.GDbarreraObjects1});
gdjs.NivelCode.eventsList13 = function(runtimeScene) {

{

/* Reuse gdjs.NivelCode.GDbarreraObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDbarreraObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDbarreraObjects1[i].getVariableNumber(gdjs.NivelCode.GDbarreraObjects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDbarreraObjects1[k] = gdjs.NivelCode.GDbarreraObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDbarreraObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDbarreraObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDbarreraObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDbarreraObjects1[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1, "HUMA": gdjs.NivelCode.GDHUMAObjects1, "LATA": gdjs.NivelCode.GDLATAObjects1, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects = Hashtable.newFrom({"barrera": gdjs.NivelCode.GDbarreraObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1, "HUMA": gdjs.NivelCode.GDHUMAObjects1, "LATA": gdjs.NivelCode.GDLATAObjects1, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1, "HUMA": gdjs.NivelCode.GDHUMAObjects1, "LATA": gdjs.NivelCode.GDLATAObjects1, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHitParticlesObjects1Objects = Hashtable.newFrom({"HitParticles": gdjs.NivelCode.GDHitParticlesObjects1});
gdjs.NivelCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 4);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_1"), gdjs.NivelCode.GDVida_95951Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95951Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95951Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_2"), gdjs.NivelCode.GDVida_95952Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95952Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95952Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_3"), gdjs.NivelCode.GDVida_95953Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95953Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95953Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_4"), gdjs.NivelCode.GDVida_95954Objects2);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95954Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95954Objects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_5"), gdjs.NivelCode.GDVida_95955Objects1);
{for(var i = 0, len = gdjs.NivelCode.GDVida_95955Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95955Objects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.eventsList15 = function(runtimeScene) {

};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects = Hashtable.newFrom({"barrera": gdjs.NivelCode.GDbarreraObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects = Hashtable.newFrom({"barrera": gdjs.NivelCode.GDbarreraObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy1Objects1ObjectsGDgdjs_9546NivelCode_9546GDproyectilObjects1ObjectsGDgdjs_9546NivelCode_9546GDenemy2Objects1ObjectsGDgdjs_9546NivelCode_9546GDenemy3Objects1ObjectsGDgdjs_9546NivelCode_9546GDPuruObjects1Objects = Hashtable.newFrom({"enemy1": gdjs.NivelCode.GDenemy1Objects1, "proyectil": gdjs.NivelCode.GDproyectilObjects1, "enemy2": gdjs.NivelCode.GDenemy2Objects1, "enemy3": gdjs.NivelCode.GDenemy3Objects1, "Puru": gdjs.NivelCode.GDPuruObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects3});
gdjs.NivelCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects3.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDSamiObjects3[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects3[k] = gdjs.NivelCode.GDSamiObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects3.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDHUMAObjects3[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects3[k] = gdjs.NivelCode.GDHUMAObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects3.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDLATAObjects3[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects3[k] = gdjs.NivelCode.GDLATAObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects3.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects3[k] = gdjs.NivelCode.GDCURIQUINGUEObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects3 */
/* Reuse gdjs.NivelCode.GDHUMAObjects3 */
/* Reuse gdjs.NivelCode.GDLATAObjects3 */
/* Reuse gdjs.NivelCode.GDSamiObjects3 */
gdjs.NivelCode.GDproyectil_9595jugadorObjects3.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDSamiObjects3[i].getCenterXInScene()), (gdjs.NivelCode.GDSamiObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 0, 300, null);
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDHUMAObjects3[i].getCenterXInScene()), (gdjs.NivelCode.GDHUMAObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 0, 300, null);
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDLATAObjects3[i].getCenterXInScene()), (gdjs.NivelCode.GDLATAObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 0, 300, null);
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getCenterXInScene()), (gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 0, 300, null);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects3.length;i<l;++i) {
    if ( gdjs.NivelCode.GDSamiObjects3[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects3[k] = gdjs.NivelCode.GDSamiObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects3.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHUMAObjects3[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects3[k] = gdjs.NivelCode.GDHUMAObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects3.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects3[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects3[k] = gdjs.NivelCode.GDLATAObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects3.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects3[k] = gdjs.NivelCode.GDCURIQUINGUEObjects3[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects3 */
/* Reuse gdjs.NivelCode.GDHUMAObjects3 */
/* Reuse gdjs.NivelCode.GDLATAObjects3 */
/* Reuse gdjs.NivelCode.GDSamiObjects3 */
gdjs.NivelCode.GDproyectil_9595jugadorObjects3.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDSamiObjects3[i].getCenterXInScene()) - 16, (gdjs.NivelCode.GDSamiObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 180, 300, null);
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDHUMAObjects3[i].getCenterXInScene()) - 16, (gdjs.NivelCode.GDHUMAObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 180, 300, null);
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDLATAObjects3[i].getCenterXInScene()) - 16, (gdjs.NivelCode.GDLATAObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 180, 300, null);
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getBehavior("FireBullet").Fire((gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getCenterXInScene()) - 16, (gdjs.NivelCode.GDCURIQUINGUEObjects3[i].getCenterYInScene()), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects3Objects, 180, 300, null);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

gdjs.NivelCode.forEachTotalCount2 = 0;
gdjs.NivelCode.forEachObjects2.length = 0;
gdjs.NivelCode.forEachCount0_2 = gdjs.NivelCode.GDSamiObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount0_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDSamiObjects1);
gdjs.NivelCode.forEachCount1_2 = gdjs.NivelCode.GDHUMAObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount1_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDHUMAObjects1);
gdjs.NivelCode.forEachCount2_2 = gdjs.NivelCode.GDLATAObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount2_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDLATAObjects1);
gdjs.NivelCode.forEachCount3_2 = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount3_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDCURIQUINGUEObjects1);
for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachTotalCount2;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;

gdjs.NivelCode.GDHUMAObjects2.length = 0;

gdjs.NivelCode.GDLATAObjects2.length = 0;

gdjs.NivelCode.GDSamiObjects2.length = 0;


if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2) {
    gdjs.NivelCode.GDSamiObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2) {
    gdjs.NivelCode.GDHUMAObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2+gdjs.NivelCode.forEachCount2_2) {
    gdjs.NivelCode.GDLATAObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2+gdjs.NivelCode.forEachCount2_2+gdjs.NivelCode.forEachCount3_2) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.NivelCode.eventsList16(runtimeScene);} //Subevents end.
}
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects2Objects = Hashtable.newFrom({"enemy3": gdjs.NivelCode.GDenemy3Objects2});
gdjs.NivelCode.eventsList18 = function(runtimeScene) {

};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects2Objects = Hashtable.newFrom({"enemy3": gdjs.NivelCode.GDenemy3Objects2});
gdjs.NivelCode.eventsList19 = function(runtimeScene) {

};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects1Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects1Objects = Hashtable.newFrom({"enemy3": gdjs.NivelCode.GDenemy3Objects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHitParticlesObjects1Objects = Hashtable.newFrom({"HitParticles": gdjs.NivelCode.GDHitParticlesObjects1});
gdjs.NivelCode.eventsList20 = function(runtimeScene) {

{

/* Reuse gdjs.NivelCode.GDenemy3Objects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy3Objects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy3Objects1[i].getVariableNumber(gdjs.NivelCode.GDenemy3Objects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy3Objects1[k] = gdjs.NivelCode.GDenemy3Objects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy3Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects1 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDPuruObjects2, gdjs.NivelCode.GDPuruObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getPointX("")) :gdjs.NivelCode.GDHUMAObjects3[0].getPointX("")) :gdjs.NivelCode.GDLATAObjects3[0].getPointX("")) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getPointX("")) > (( gdjs.NivelCode.GDPuruObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects3[0].getPointX("")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDPuruObjects3 */
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects3[i].getBehavior("PlatformerObject").setCurrentSpeed(80);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects2, gdjs.NivelCode.GDCURIQUINGUEObjects3);

gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects2, gdjs.NivelCode.GDHUMAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDLATAObjects2, gdjs.NivelCode.GDLATAObjects3);

gdjs.copyArray(gdjs.NivelCode.GDPuruObjects2, gdjs.NivelCode.GDPuruObjects3);

gdjs.copyArray(gdjs.NivelCode.GDSamiObjects2, gdjs.NivelCode.GDSamiObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDCURIQUINGUEObjects3.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects3.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects3[0].getPointX("")) :gdjs.NivelCode.GDHUMAObjects3[0].getPointX("")) :gdjs.NivelCode.GDLATAObjects3[0].getPointX("")) :gdjs.NivelCode.GDCURIQUINGUEObjects3[0].getPointX("")) <= (( gdjs.NivelCode.GDPuruObjects3.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects3[0].getPointX("")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDPuruObjects3 */
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects3.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects3[i].getBehavior("PlatformerObject").setCurrentSpeed(-(80));
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDpiedrasoObjects1Objects = Hashtable.newFrom({"piedraso": gdjs.NivelCode.GDpiedrasoObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects2Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects2});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects2, "HUMA": gdjs.NivelCode.GDHUMAObjects2, "LATA": gdjs.NivelCode.GDLATAObjects2, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects2});
gdjs.NivelCode.eventsList22 = function(runtimeScene) {

};gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects = Hashtable.newFrom({"proyectil": gdjs.NivelCode.GDproyectilObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1, "HUMA": gdjs.NivelCode.GDHUMAObjects1, "LATA": gdjs.NivelCode.GDLATAObjects1, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHitParticlesObjects1Objects = Hashtable.newFrom({"HitParticles": gdjs.NivelCode.GDHitParticlesObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects1Objects = Hashtable.newFrom({"proyectil_jugador": gdjs.NivelCode.GDproyectil_9595jugadorObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDPuruObjects1Objects = Hashtable.newFrom({"Puru": gdjs.NivelCode.GDPuruObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDTrofeoObjects1Objects = Hashtable.newFrom({"Trofeo": gdjs.NivelCode.GDTrofeoObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects = Hashtable.newFrom({"Sami": gdjs.NivelCode.GDSamiObjects1, "HUMA": gdjs.NivelCode.GDHUMAObjects1, "LATA": gdjs.NivelCode.GDLATAObjects1, "CURIQUINGUE": gdjs.NivelCode.GDCURIQUINGUEObjects1});
gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDTrofeoObjects1Objects = Hashtable.newFrom({"Trofeo": gdjs.NivelCode.GDTrofeoObjects1});
gdjs.NivelCode.eventsList23 = function(runtimeScene) {

};gdjs.NivelCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

gdjs.NivelCode.forEachTotalCount2 = 0;
gdjs.NivelCode.forEachObjects2.length = 0;
gdjs.NivelCode.forEachCount0_2 = gdjs.NivelCode.GDSamiObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount0_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDSamiObjects1);
gdjs.NivelCode.forEachCount1_2 = gdjs.NivelCode.GDHUMAObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount1_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDHUMAObjects1);
gdjs.NivelCode.forEachCount2_2 = gdjs.NivelCode.GDLATAObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount2_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDLATAObjects1);
gdjs.NivelCode.forEachCount3_2 = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount3_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDCURIQUINGUEObjects1);
for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachTotalCount2;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;

gdjs.NivelCode.GDHUMAObjects2.length = 0;

gdjs.NivelCode.GDLATAObjects2.length = 0;

gdjs.NivelCode.GDSamiObjects2.length = 0;


if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2) {
    gdjs.NivelCode.GDSamiObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2) {
    gdjs.NivelCode.GDHUMAObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2+gdjs.NivelCode.forEachCount2_2) {
    gdjs.NivelCode.GDLATAObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2+gdjs.NivelCode.forEachCount2_2+gdjs.NivelCode.forEachCount3_2) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}
}

}


};gdjs.NivelCode.eventsList25 = function(runtimeScene) {

};gdjs.NivelCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

gdjs.NivelCode.forEachTotalCount2 = 0;
gdjs.NivelCode.forEachObjects2.length = 0;
gdjs.NivelCode.forEachCount0_2 = gdjs.NivelCode.GDSamiObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount0_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDSamiObjects1);
gdjs.NivelCode.forEachCount1_2 = gdjs.NivelCode.GDHUMAObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount1_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDHUMAObjects1);
gdjs.NivelCode.forEachCount2_2 = gdjs.NivelCode.GDLATAObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount2_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDLATAObjects1);
gdjs.NivelCode.forEachCount3_2 = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;
gdjs.NivelCode.forEachTotalCount2 += gdjs.NivelCode.forEachCount3_2;
gdjs.NivelCode.forEachObjects2.push.apply(gdjs.NivelCode.forEachObjects2,gdjs.NivelCode.GDCURIQUINGUEObjects1);
for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachTotalCount2;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;

gdjs.NivelCode.GDHUMAObjects2.length = 0;

gdjs.NivelCode.GDLATAObjects2.length = 0;

gdjs.NivelCode.GDSamiObjects2.length = 0;


if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2) {
    gdjs.NivelCode.GDSamiObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2) {
    gdjs.NivelCode.GDHUMAObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2+gdjs.NivelCode.forEachCount2_2) {
    gdjs.NivelCode.GDLATAObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
else if (gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.forEachCount0_2+gdjs.NivelCode.forEachCount1_2+gdjs.NivelCode.forEachCount2_2+gdjs.NivelCode.forEachCount3_2) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2.push(gdjs.NivelCode.forEachObjects2[gdjs.NivelCode.forEachIndex2]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}
}

}


};gdjs.NivelCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(800);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setJumpSustainTime(0.35);
}
}
elseEventsChainSatisfied = true;
}

}


};gdjs.NivelCode.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio para GGJ.mp3", true, 100, 1);
}
elseEventsChainSatisfied = true;
}

}


{


gdjs.NivelCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.NivelCode.GDSamiObjects1.length !== 0 ? gdjs.NivelCode.GDSamiObjects1[0] : null), true, "", 0);
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects1[k] = gdjs.NivelCode.GDSamiObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("Animation").setAnimationName("Caminar");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects1.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects1[k] = gdjs.NivelCode.GDSamiObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("Animation").setAnimationName("Descanzo");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects1[k] = gdjs.NivelCode.GDSamiObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("Flippable").flipX(true);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects1[k] = gdjs.NivelCode.GDSamiObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("Flippable").flipX(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects1[k] = gdjs.NivelCode.GDSamiObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("Animation").setAnimationName("salto y caída ");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].setAnimationFrame(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDSamiObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDSamiObjects1[k] = gdjs.NivelCode.GDSamiObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDSamiObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("Animation").setAnimationName("salto y caída ");
}
}
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].setAnimationFrame(1);
}
}
elseEventsChainSatisfied = true;
}

}


{


gdjs.NivelCode.eventsList1(runtimeScene);
}


{


gdjs.NivelCode.eventsList2(runtimeScene);
}


{


gdjs.NivelCode.eventsList3(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_1"), gdjs.NivelCode.GDVida_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_2"), gdjs.NivelCode.GDVida_95952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_3"), gdjs.NivelCode.GDVida_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_4"), gdjs.NivelCode.GDVida_95954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_5"), gdjs.NivelCode.GDVida_95955Objects1);
gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(5);
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95951Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95951Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95952Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95952Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95953Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95953Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95954Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95954Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95955Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95955Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects1[i].getBehavior("FireBullet").SetCooldownOp(1.5, null);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects1[i].getBehavior("FireBullet").SetRotateBullet(true, null);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects1[i].getBehavior("FireBullet").SetBulletLayer("", null);
}
}

{ //Subevents
gdjs.NivelCode.eventsList5(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.NivelCode.GDCURIQUINGUEObjects1.length = 0;

gdjs.NivelCode.GDHUMAObjects1.length = 0;

gdjs.NivelCode.GDLATAObjects1.length = 0;

gdjs.NivelCode.GDPuruObjects1.length = 0;

gdjs.NivelCode.GDSamiObjects1.length = 0;

gdjs.NivelCode.GDenemy1Objects1.length = 0;

gdjs.NivelCode.GDenemy2Objects1.length = 0;

gdjs.NivelCode.GDenemy3Objects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.length = 0;
gdjs.NivelCode.GDHUMAObjects1_1final.length = 0;
gdjs.NivelCode.GDLATAObjects1_1final.length = 0;
gdjs.NivelCode.GDPuruObjects1_1final.length = 0;
gdjs.NivelCode.GDSamiObjects1_1final.length = 0;
gdjs.NivelCode.GDenemy1Objects1_1final.length = 0;
gdjs.NivelCode.GDenemy2Objects1_1final.length = 0;
gdjs.NivelCode.GDenemy3Objects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemy1"), gdjs.NivelCode.GDenemy1Objects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy1Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.NivelCode.GDCURIQUINGUEObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.indexOf(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]) === -1 )
            gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.push(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDHUMAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDHUMAObjects1_1final.indexOf(gdjs.NivelCode.GDHUMAObjects2[j]) === -1 )
            gdjs.NivelCode.GDHUMAObjects1_1final.push(gdjs.NivelCode.GDHUMAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDLATAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDLATAObjects1_1final.indexOf(gdjs.NivelCode.GDLATAObjects2[j]) === -1 )
            gdjs.NivelCode.GDLATAObjects1_1final.push(gdjs.NivelCode.GDLATAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDSamiObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDSamiObjects1_1final.indexOf(gdjs.NivelCode.GDSamiObjects2[j]) === -1 )
            gdjs.NivelCode.GDSamiObjects1_1final.push(gdjs.NivelCode.GDSamiObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDenemy1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDenemy1Objects1_1final.indexOf(gdjs.NivelCode.GDenemy1Objects2[j]) === -1 )
            gdjs.NivelCode.GDenemy1Objects1_1final.push(gdjs.NivelCode.GDenemy1Objects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemy2"), gdjs.NivelCode.GDenemy2Objects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy2Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.NivelCode.GDCURIQUINGUEObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.indexOf(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]) === -1 )
            gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.push(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDHUMAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDHUMAObjects1_1final.indexOf(gdjs.NivelCode.GDHUMAObjects2[j]) === -1 )
            gdjs.NivelCode.GDHUMAObjects1_1final.push(gdjs.NivelCode.GDHUMAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDLATAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDLATAObjects1_1final.indexOf(gdjs.NivelCode.GDLATAObjects2[j]) === -1 )
            gdjs.NivelCode.GDLATAObjects1_1final.push(gdjs.NivelCode.GDLATAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDSamiObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDSamiObjects1_1final.indexOf(gdjs.NivelCode.GDSamiObjects2[j]) === -1 )
            gdjs.NivelCode.GDSamiObjects1_1final.push(gdjs.NivelCode.GDSamiObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDenemy2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDenemy2Objects1_1final.indexOf(gdjs.NivelCode.GDenemy2Objects2[j]) === -1 )
            gdjs.NivelCode.GDenemy2Objects1_1final.push(gdjs.NivelCode.GDenemy2Objects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.NivelCode.GDCURIQUINGUEObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.indexOf(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]) === -1 )
            gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.push(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDHUMAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDHUMAObjects1_1final.indexOf(gdjs.NivelCode.GDHUMAObjects2[j]) === -1 )
            gdjs.NivelCode.GDHUMAObjects1_1final.push(gdjs.NivelCode.GDHUMAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDLATAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDLATAObjects1_1final.indexOf(gdjs.NivelCode.GDLATAObjects2[j]) === -1 )
            gdjs.NivelCode.GDLATAObjects1_1final.push(gdjs.NivelCode.GDLATAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDSamiObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDSamiObjects1_1final.indexOf(gdjs.NivelCode.GDSamiObjects2[j]) === -1 )
            gdjs.NivelCode.GDSamiObjects1_1final.push(gdjs.NivelCode.GDSamiObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDenemy3Objects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDenemy3Objects1_1final.indexOf(gdjs.NivelCode.GDenemy3Objects2[j]) === -1 )
            gdjs.NivelCode.GDenemy3Objects1_1final.push(gdjs.NivelCode.GDenemy3Objects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDPuruObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.NivelCode.GDCURIQUINGUEObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.indexOf(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]) === -1 )
            gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.push(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDHUMAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDHUMAObjects1_1final.indexOf(gdjs.NivelCode.GDHUMAObjects2[j]) === -1 )
            gdjs.NivelCode.GDHUMAObjects1_1final.push(gdjs.NivelCode.GDHUMAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDLATAObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDLATAObjects1_1final.indexOf(gdjs.NivelCode.GDLATAObjects2[j]) === -1 )
            gdjs.NivelCode.GDLATAObjects1_1final.push(gdjs.NivelCode.GDLATAObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDPuruObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDPuruObjects1_1final.indexOf(gdjs.NivelCode.GDPuruObjects2[j]) === -1 )
            gdjs.NivelCode.GDPuruObjects1_1final.push(gdjs.NivelCode.GDPuruObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.NivelCode.GDSamiObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDSamiObjects1_1final.indexOf(gdjs.NivelCode.GDSamiObjects2[j]) === -1 )
            gdjs.NivelCode.GDSamiObjects1_1final.push(gdjs.NivelCode.GDSamiObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects1_1final, gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(gdjs.NivelCode.GDHUMAObjects1_1final, gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(gdjs.NivelCode.GDLATAObjects1_1final, gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(gdjs.NivelCode.GDPuruObjects1_1final, gdjs.NivelCode.GDPuruObjects1);
gdjs.copyArray(gdjs.NivelCode.GDSamiObjects1_1final, gdjs.NivelCode.GDSamiObjects1);
gdjs.copyArray(gdjs.NivelCode.GDenemy1Objects1_1final, gdjs.NivelCode.GDenemy1Objects1);
gdjs.copyArray(gdjs.NivelCode.GDenemy2Objects1_1final, gdjs.NivelCode.GDenemy2Objects1);
gdjs.copyArray(gdjs.NivelCode.GDenemy3Objects1_1final, gdjs.NivelCode.GDenemy3Objects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18329732);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}

{ //Subevents
gdjs.NivelCode.eventsList6(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", true);
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].returnVariable(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getVariableNumber(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].returnVariable(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(2)).setNumber((gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").getJumpSustainTime()));
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").setJumpSustainTime(1);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").setJumpSustainTime(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(2).getAsNumber());
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
gdjs.copyArray(runtimeScene.getObjects("pinchos"), gdjs.NivelCode.GDpinchosObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDpinchosObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18340412);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Vida_1"), gdjs.NivelCode.GDVida_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_2"), gdjs.NivelCode.GDVida_95952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_3"), gdjs.NivelCode.GDVida_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_4"), gdjs.NivelCode.GDVida_95954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Vida_5"), gdjs.NivelCode.GDVida_95955Objects1);
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(0);
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95951Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95951Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95952Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95952Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95953Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95953Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95954Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95954Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDVida_95955Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDVida_95955Objects1[i].hide();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy1"), gdjs.NivelCode.GDenemy1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy1Objects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy1Objects1[i].getBehavior("Animation").getAnimationName() == "descanso1" ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy1Objects1[k] = gdjs.NivelCode.GDenemy1Objects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy1Objects1.length = k;
if (isConditionTrue_0) {
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy1"), gdjs.NivelCode.GDenemy1Objects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy1Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDenemy1Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy1Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy1Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.NivelCode.eventsList7(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy2"), gdjs.NivelCode.GDenemy2Objects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy2Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDenemy2Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy2Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy2Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.NivelCode.eventsList8(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy3Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.NivelCode.GDenemy3Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy3Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy3Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.pickNearestObject(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, (( gdjs.NivelCode.GDenemy3Objects2.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects2[0].getCenterXInScene()), (( gdjs.NivelCode.GDenemy3Objects2.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects2[0].getCenterYInScene()));
}

{ //Subevents: 
gdjs.NivelCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy3Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.NivelCode.GDenemy3Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy3Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy3Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.pickNearestObject(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, (( gdjs.NivelCode.GDenemy3Objects2.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects2[0].getCenterXInScene()), (( gdjs.NivelCode.GDenemy3Objects2.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects2[0].getCenterYInScene()));
}

{ //Subevents: 
gdjs.NivelCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDPuruObjects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDPuruObjects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDPuruObjects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDPuruObjects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.NivelCode.eventsList11(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.clampCamera(runtimeScene, 30, -(10), 13600, 447, "", 0);
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy3Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDenemy3Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy3Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy3Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy3Objects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy3Objects2[i].getTimerElapsedTimeInSecondsOrNaN("FireTimer") > 1.5 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy3Objects2[k] = gdjs.NivelCode.GDenemy3Objects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy3Objects2.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects2[i].resetTimer("FireTimer");
}
}

{ //Subevents: 
gdjs.NivelCode.eventsList12(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("barrera"), gdjs.NivelCode.GDbarreraObjects1);
gdjs.copyArray(runtimeScene.getObjects("proyectil"), gdjs.NivelCode.GDproyectilObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDbarreraObjects1 */
/* Reuse gdjs.NivelCode.GDproyectilObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDproyectilObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDproyectilObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDbarreraObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDbarreraObjects1[i].returnVariable(gdjs.NivelCode.GDbarreraObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}

{ //Subevents
gdjs.NivelCode.eventsList13(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
gdjs.copyArray(runtimeScene.getObjects("barrera"), gdjs.NivelCode.GDbarreraObjects1);
gdjs.copyArray(runtimeScene.getObjects("proyectil"), gdjs.NivelCode.GDproyectilObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDbarreraObjects1 */
/* Reuse gdjs.NivelCode.GDproyectilObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDproyectilObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDproyectilObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDbarreraObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDbarreraObjects1[i].returnVariable(gdjs.NivelCode.GDbarreraObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
gdjs.copyArray(runtimeScene.getObjects("proyectil"), gdjs.NivelCode.GDproyectilObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
/* Reuse gdjs.NivelCode.GDHUMAObjects1 */
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
/* Reuse gdjs.NivelCode.GDproyectilObjects1 */
gdjs.NivelCode.GDHitParticlesObjects1.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].returnVariable(gdjs.NivelCode.GDSamiObjects1[i].getVariables().get("lives")).sub(1);
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects1[i].returnVariable(gdjs.NivelCode.GDHUMAObjects1[i].getVariables().get("lives")).sub(1);
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].returnVariable(gdjs.NivelCode.GDLATAObjects1[i].getVariables().get("lives")).sub(1);
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().get("lives")).sub(1);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(4).sub(1);
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHitParticlesObjects1Objects, (( gdjs.NivelCode.GDproyectilObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDproyectilObjects1[0].getPointX("")), (( gdjs.NivelCode.GDproyectilObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDproyectilObjects1[0].getPointY("")), (( gdjs.NivelCode.GDproyectilObjects1.length === 0 ) ? "" :gdjs.NivelCode.GDproyectilObjects1[0].getLayer()));
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].setTank(30);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].setFlow(200);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].jumpEmitterForwardInTime(0.1);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].startEmission();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDproyectilObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDproyectilObjects1[i].deleteFromScene(runtimeScene);
}
}

{ //Subevents
gdjs.NivelCode.eventsList14(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HitParticles"), gdjs.NivelCode.GDHitParticlesObjects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDHitParticlesObjects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.NivelCode.GDHitParticlesObjects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDHitParticlesObjects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDHitParticlesObjects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHitParticlesObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHitParticlesObjects2[i].noMoreParticles() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHitParticlesObjects2[k] = gdjs.NivelCode.GDHitParticlesObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDHitParticlesObjects2.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects2[i].deleteFromScene(runtimeScene);
}
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDHUMAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDHUMAObjects1[i].getVariableNumber(gdjs.NivelCode.GDHUMAObjects1[i].getVariables().getFromIndex(2)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDHUMAObjects1[k] = gdjs.NivelCode.GDHUMAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDHUMAObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18370564);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDHUMAObjects1 */
gdjs.NivelCode.GDbarreraObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects, (( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects1[0].getPointX("")), (( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects1[0].getPointY("")), "");
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("barrera"), gdjs.NivelCode.GDbarreraObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDbarreraObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDbarreraObjects1[i].setPosition((( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects1[0].getCenterXInScene()),(( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDHUMAObjects1[0].getCenterYInScene()));
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects1[i].returnVariable(gdjs.NivelCode.GDHUMAObjects1[i].getVariables().getFromIndex(2)).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);
gdjs.copyArray(runtimeScene.getObjects("barrera"), gdjs.NivelCode.GDbarreraObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemy1"), gdjs.NivelCode.GDenemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("enemy2"), gdjs.NivelCode.GDenemy2Objects1);
gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);
gdjs.copyArray(runtimeScene.getObjects("proyectil"), gdjs.NivelCode.GDproyectilObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDbarreraObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy1Objects1ObjectsGDgdjs_9546NivelCode_9546GDproyectilObjects1ObjectsGDgdjs_9546NivelCode_9546GDenemy2Objects1ObjectsGDgdjs_9546NivelCode_9546GDenemy3Objects1ObjectsGDgdjs_9546NivelCode_9546GDPuruObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
/* Reuse gdjs.NivelCode.GDbarreraObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDbarreraObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDbarreraObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects1[i].returnVariable(gdjs.NivelCode.GDHUMAObjects1[i].getVariables().getFromIndex(2)).setNumber(7);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
if (isConditionTrue_0) {

{ //Subevents
gdjs.NivelCode.eventsList17(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy2"), gdjs.NivelCode.GDenemy2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy2Objects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy2Objects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy2Objects1[k] = gdjs.NivelCode.GDenemy2Objects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy2Objects1 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects1[i].getBehavior("Animation").setAnimationName("caminando");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy3Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.NivelCode.GDenemy3Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy3Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy3Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects2Objects, 180, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects2[i].returnVariable(gdjs.NivelCode.GDenemy3Objects2[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDenemy3Objects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.NivelCode.GDenemy3Objects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDenemy3Objects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDenemy3Objects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects2Objects, 180, true);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects2.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects2[i].returnVariable(gdjs.NivelCode.GDenemy3Objects2[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
}
}

}


{


let isConditionTrue_0 = false;
{
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy3"), gdjs.NivelCode.GDenemy3Objects1);
gdjs.copyArray(runtimeScene.getObjects("proyectil_jugador"), gdjs.NivelCode.GDproyectil_9595jugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDenemy3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy3Objects1 */
/* Reuse gdjs.NivelCode.GDproyectil_9595jugadorObjects1 */
gdjs.NivelCode.GDHitParticlesObjects1.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDproyectil_9595jugadorObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDproyectil_9595jugadorObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy3Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy3Objects1[i].returnVariable(gdjs.NivelCode.GDenemy3Objects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHitParticlesObjects1Objects, (( gdjs.NivelCode.GDenemy3Objects1.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects1[0].getPointX("")), (( gdjs.NivelCode.GDenemy3Objects1.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy3Objects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].setTank(30);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].setFlow(200);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].jumpEmitterForwardInTime(0.1);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].startEmission();
}
}

{ //Subevents
gdjs.NivelCode.eventsList20(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("enemy2"), gdjs.NivelCode.GDenemy2Objects1);
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects1[i].getBehavior("Flippable").flipX(false);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber((( gdjs.NivelCode.GDenemy2Objects1.length === 0 ) ? 0 :gdjs.NivelCode.GDenemy2Objects1[0].getPointX("")));
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects1[i].returnVariable(gdjs.NivelCode.GDenemy2Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy2"), gdjs.NivelCode.GDenemy2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy2Objects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy2Objects1[i].getVariableNumber(gdjs.NivelCode.GDenemy2Objects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDenemy2Objects1[k] = gdjs.NivelCode.GDenemy2Objects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.NivelCode.GDenemy2Objects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.NivelCode.GDenemy2Objects1, gdjs.NivelCode.GDenemy2Objects2);

for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy2Objects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy2Objects2[i].getX() >= runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() + 200 ) {
        isConditionTrue_1 = true;
        gdjs.NivelCode.GDenemy2Objects2[k] = gdjs.NivelCode.GDenemy2Objects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy2Objects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.NivelCode.GDenemy2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDenemy2Objects1_1final.indexOf(gdjs.NivelCode.GDenemy2Objects2[j]) === -1 )
            gdjs.NivelCode.GDenemy2Objects1_1final.push(gdjs.NivelCode.GDenemy2Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.NivelCode.GDenemy2Objects1, gdjs.NivelCode.GDenemy2Objects2);

for (var i = 0, k = 0, l = gdjs.NivelCode.GDenemy2Objects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDenemy2Objects2[i].getX() <= runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() - 200 ) {
        isConditionTrue_1 = true;
        gdjs.NivelCode.GDenemy2Objects2[k] = gdjs.NivelCode.GDenemy2Objects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDenemy2Objects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.NivelCode.GDenemy2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDenemy2Objects1_1final.indexOf(gdjs.NivelCode.GDenemy2Objects2[j]) === -1 )
            gdjs.NivelCode.GDenemy2Objects1_1final.push(gdjs.NivelCode.GDenemy2Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.NivelCode.GDenemy2Objects1_1final, gdjs.NivelCode.GDenemy2Objects1);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDenemy2Objects1 */
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects1[i].returnVariable(gdjs.NivelCode.GDenemy2Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects1[i].activateBehavior("TimedBackAndForthMirroredMovement", false);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDenemy2Objects1.length ;i < len;++i) {
    gdjs.NivelCode.GDenemy2Objects1[i].rotate(720, runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].getBehavior("PlatformerObject").setGravity(0);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(120);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].getBehavior("PlatformerObject").setAcceleration(2000);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].getBehavior("PlatformerObject").setDeceleration(2000);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDPuruObjects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.NivelCode.GDPuruObjects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDPuruObjects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDPuruObjects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.pickNearestObject(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, (( gdjs.NivelCode.GDPuruObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects2[0].getCenterXInScene()), (( gdjs.NivelCode.GDPuruObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects2[0].getCenterYInScene()));
}
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects2[i].getBehavior("PlatformerObject").setCurrentFallSpeed(0);
}
}

{ //Subevents: 
gdjs.NivelCode.eventsList21(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(5).add(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() >= runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);
gdjs.NivelCode.GDpiedrasoObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDpiedrasoObjects1Objects, (( gdjs.NivelCode.GDPuruObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects1[0].getCenterXInScene()) + gdjs.randomInRange(-(50), 50), 50, "");
}
{for(var i = 0, len = gdjs.NivelCode.GDpiedrasoObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDpiedrasoObjects1[i].addForce(0, 200, 1);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(gdjs.randomFloatInRange(0.5, 2));
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);

for (gdjs.NivelCode.forEachIndex2 = 0;gdjs.NivelCode.forEachIndex2 < gdjs.NivelCode.GDPuruObjects1.length;++gdjs.NivelCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects2);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects2);
gdjs.NivelCode.GDproyectilObjects2.length = 0;

gdjs.NivelCode.GDPuruObjects2.length = 0;


gdjs.NivelCode.forEachTemporary2 = gdjs.NivelCode.GDPuruObjects1[gdjs.NivelCode.forEachIndex2];
gdjs.NivelCode.GDPuruObjects2.push(gdjs.NivelCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = (Math.abs((( gdjs.NivelCode.GDPuruObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects2[0].getPointX("")) - (( gdjs.NivelCode.GDCURIQUINGUEObjects2.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects2.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects2.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointX("")) :gdjs.NivelCode.GDHUMAObjects2[0].getPointX("")) :gdjs.NivelCode.GDLATAObjects2[0].getPointX("")) :gdjs.NivelCode.GDCURIQUINGUEObjects2[0].getPointX(""))) <= 180);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (Math.abs((( gdjs.NivelCode.GDPuruObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects2[0].getPointY("")) - (( gdjs.NivelCode.GDCURIQUINGUEObjects2.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects2.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects2.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects2.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects2[0].getPointY("")) :gdjs.NivelCode.GDHUMAObjects2[0].getPointY("")) :gdjs.NivelCode.GDLATAObjects2[0].getPointY("")) :gdjs.NivelCode.GDCURIQUINGUEObjects2[0].getPointY(""))) <= 180);
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects2.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects2[i].getBehavior("FireBullet").FireTowardObject((gdjs.NivelCode.GDPuruObjects2[i].getPointX("")), (gdjs.NivelCode.GDPuruObjects2[i].getPointY("")), gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects2Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects2ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects2ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects2ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects2Objects, 250, null);
}
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
gdjs.copyArray(runtimeScene.getObjects("proyectil"), gdjs.NivelCode.GDproyectilObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectilObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
/* Reuse gdjs.NivelCode.GDHUMAObjects1 */
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
/* Reuse gdjs.NivelCode.GDSamiObjects1 */
/* Reuse gdjs.NivelCode.GDproyectilObjects1 */
gdjs.NivelCode.GDHitParticlesObjects1.length = 0;

{for(var i = 0, len = gdjs.NivelCode.GDproyectilObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDproyectilObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].returnVariable(gdjs.NivelCode.GDSamiObjects1[i].getVariables().get("lives")).sub(1);
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects1[i].returnVariable(gdjs.NivelCode.GDHUMAObjects1[i].getVariables().get("lives")).sub(1);
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].returnVariable(gdjs.NivelCode.GDLATAObjects1[i].getVariables().get("lives")).sub(1);
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().get("lives")).sub(1);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDHitParticlesObjects1Objects, (( gdjs.NivelCode.GDCURIQUINGUEObjects1.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects1.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects1[0].getPointX("")) :gdjs.NivelCode.GDHUMAObjects1[0].getPointX("")) :gdjs.NivelCode.GDLATAObjects1[0].getPointX("")) :gdjs.NivelCode.GDCURIQUINGUEObjects1[0].getPointX("")), (( gdjs.NivelCode.GDCURIQUINGUEObjects1.length === 0 ) ? (( gdjs.NivelCode.GDLATAObjects1.length === 0 ) ? (( gdjs.NivelCode.GDHUMAObjects1.length === 0 ) ? (( gdjs.NivelCode.GDSamiObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDSamiObjects1[0].getPointY("")) :gdjs.NivelCode.GDHUMAObjects1[0].getPointY("")) :gdjs.NivelCode.GDLATAObjects1[0].getPointY("")) :gdjs.NivelCode.GDCURIQUINGUEObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].setTank(30);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].setFlow(200);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].jumpEmitterForwardInTime(0.1);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDHitParticlesObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHitParticlesObjects1[i].startEmission();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].getBehavior("FireBullet").SetBulletLayer("", null);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);
gdjs.copyArray(runtimeScene.getObjects("proyectil_jugador"), gdjs.NivelCode.GDproyectil_9595jugadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDproyectil_95959595jugadorObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDPuruObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDPuruObjects1 */
/* Reuse gdjs.NivelCode.GDproyectil_9595jugadorObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDproyectil_9595jugadorObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDproyectil_9595jugadorObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].returnVariable(gdjs.NivelCode.GDPuruObjects1[i].getVariables().getFromIndex(0)).add(1);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Puru"), gdjs.NivelCode.GDPuruObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDPuruObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDPuruObjects1[i].getVariableNumber(gdjs.NivelCode.GDPuruObjects1[i].getVariables().getFromIndex(0)) >= 60 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDPuruObjects1[k] = gdjs.NivelCode.GDPuruObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDPuruObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDPuruObjects1 */
gdjs.NivelCode.GDTrofeoObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDTrofeoObjects1Objects, (( gdjs.NivelCode.GDPuruObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects1[0].getCenterXInScene()), (( gdjs.NivelCode.GDPuruObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDPuruObjects1[0].getCenterYInScene()), (( gdjs.NivelCode.GDPuruObjects1.length === 0 ) ? "" :gdjs.NivelCode.GDPuruObjects1[0].getLayer()));
}
{for(var i = 0, len = gdjs.NivelCode.GDPuruObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDPuruObjects1[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
gdjs.copyArray(runtimeScene.getObjects("Trofeo"), gdjs.NivelCode.GDTrofeoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDSamiObjects1ObjectsGDgdjs_9546NivelCode_9546GDHUMAObjects1ObjectsGDgdjs_9546NivelCode_9546GDLATAObjects1ObjectsGDgdjs_9546NivelCode_9546GDCURIQUINGUEObjects1Objects, gdjs.NivelCode.mapOfGDgdjs_9546NivelCode_9546GDTrofeoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDTrofeoObjects1 */
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "win", false);
}
{for(var i = 0, len = gdjs.NivelCode.GDTrofeoObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDTrofeoObjects1[i].deleteFromScene(runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MobileJoystick"), gdjs.NivelCode.GDMobileJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDMobileJoystickObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDMobileJoystickObjects1[0].StickForceX(null)) > 0.2);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.NivelCode.eventsList24(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MobileJoystick"), gdjs.NivelCode.GDMobileJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.NivelCode.GDMobileJoystickObjects1.length === 0 ) ? 0 :gdjs.NivelCode.GDMobileJoystickObjects1[0].StickForceX(null)) < -(0.2));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.NivelCode.eventsList26(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.NivelCode.GDJumpButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDJumpButtonObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDJumpButtonObjects1[i].getBehavior("MultitouchButton").IsJustPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDJumpButtonObjects1[k] = gdjs.NivelCode.GDJumpButtonObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDJumpButtonObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "l");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("HUMA"), gdjs.NivelCode.GDHUMAObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sami"), gdjs.NivelCode.GDSamiObjects1);
{for(var i = 0, len = gdjs.NivelCode.GDSamiObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDSamiObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
for(var i = 0, len = gdjs.NivelCode.GDHUMAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDHUMAObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].returnVariable(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "l");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getVariableNumber(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].returnVariable(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}

{ //Subevents
gdjs.NivelCode.eventsList27(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "l");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").setGravity(300);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.NivelCode.GDCURIQUINGUEObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "l");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects2);
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects2.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects2[k] = gdjs.NivelCode.GDCURIQUINGUEObjects2[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.NivelCode.GDCURIQUINGUEObjects2.length; j < jLen ; ++j) {
        if ( gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.indexOf(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]) === -1 )
            gdjs.NivelCode.GDCURIQUINGUEObjects1_1final.push(gdjs.NivelCode.GDCURIQUINGUEObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.NivelCode.GDCURIQUINGUEObjects1_1final, gdjs.NivelCode.GDCURIQUINGUEObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").setGravity(1000);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.NivelCode.GDJumpButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDJumpButtonObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDJumpButtonObjects1[i].getBehavior("MultitouchButton").IsJustPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDJumpButtonObjects1[k] = gdjs.NivelCode.GDJumpButtonObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDJumpButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 0);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "JumpButtonDoubleTap");
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.NivelCode.GDJumpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDJumpButtonObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDJumpButtonObjects1[i].getBehavior("MultitouchButton").IsJustPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDJumpButtonObjects1[k] = gdjs.NivelCode.GDJumpButtonObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDJumpButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "JumpButtonDoubleTap") < 0.4;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getVariableNumber(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].returnVariable(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "JumpButtonDoubleTap");
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "JumpButtonDoubleTap") > 0.4;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "JumpButtonDoubleTap");
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "l");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariableNumber(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(1)) < gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(1)).add(1);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.NivelCode.GDJumpButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDJumpButtonObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDJumpButtonObjects1[i].getBehavior("MultitouchButton").IsJustPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDJumpButtonObjects1[k] = gdjs.NivelCode.GDJumpButtonObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDJumpButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").canJump() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.NivelCode.GDJumpButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDJumpButtonObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDJumpButtonObjects1[i].getBehavior("MultitouchButton").IsJustPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDJumpButtonObjects1[k] = gdjs.NivelCode.GDJumpButtonObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDJumpButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( !(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").canJump()) ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariableNumber(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(1)) < gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(1)).add(1);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CURIQUINGUE"), gdjs.NivelCode.GDCURIQUINGUEObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDCURIQUINGUEObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDCURIQUINGUEObjects1[k] = gdjs.NivelCode.GDCURIQUINGUEObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDCURIQUINGUEObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDCURIQUINGUEObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDCURIQUINGUEObjects1[i].returnVariable(gdjs.NivelCode.GDCURIQUINGUEObjects1[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getVariableNumber(gdjs.NivelCode.GDLATAObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(800);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setJumpSustainTime(0.35);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LATA"), gdjs.NivelCode.GDLATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.NivelCode.GDLATAObjects1.length;i<l;++i) {
    if ( gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.NivelCode.GDLATAObjects1[k] = gdjs.NivelCode.GDLATAObjects1[i];
        ++k;
    }
}
gdjs.NivelCode.GDLATAObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.NivelCode.GDLATAObjects1 */
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(600);
}
}
{for(var i = 0, len = gdjs.NivelCode.GDLATAObjects1.length ;i < len;++i) {
    gdjs.NivelCode.GDLATAObjects1[i].getBehavior("PlatformerObject").setJumpSustainTime(0.2);
}
}
elseEventsChainSatisfied = true;
}

}


};

gdjs.NivelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.NivelCode.GDM_95225scara_9595HumaObjects1.length = 0;
gdjs.NivelCode.GDM_95225scara_9595HumaObjects2.length = 0;
gdjs.NivelCode.GDM_95225scara_9595HumaObjects3.length = 0;
gdjs.NivelCode.GDM_95225scara_9595HumaObjects4.length = 0;
gdjs.NivelCode.GDbackgroundObjects1.length = 0;
gdjs.NivelCode.GDbackgroundObjects2.length = 0;
gdjs.NivelCode.GDbackgroundObjects3.length = 0;
gdjs.NivelCode.GDbackgroundObjects4.length = 0;
gdjs.NivelCode.GDNewSpriteObjects1.length = 0;
gdjs.NivelCode.GDNewSpriteObjects2.length = 0;
gdjs.NivelCode.GDNewSpriteObjects3.length = 0;
gdjs.NivelCode.GDNewSpriteObjects4.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects1.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects2.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects3.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects4.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects1.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects3.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects4.length = 0;
gdjs.NivelCode.GDSamiObjects1.length = 0;
gdjs.NivelCode.GDSamiObjects2.length = 0;
gdjs.NivelCode.GDSamiObjects3.length = 0;
gdjs.NivelCode.GDSamiObjects4.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.NivelCode.GDVida_95951Objects1.length = 0;
gdjs.NivelCode.GDVida_95951Objects2.length = 0;
gdjs.NivelCode.GDVida_95951Objects3.length = 0;
gdjs.NivelCode.GDVida_95951Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects4.length = 0;
gdjs.NivelCode.GDenemy1Objects1.length = 0;
gdjs.NivelCode.GDenemy1Objects2.length = 0;
gdjs.NivelCode.GDenemy1Objects3.length = 0;
gdjs.NivelCode.GDenemy1Objects4.length = 0;
gdjs.NivelCode.GDVida_95952Objects1.length = 0;
gdjs.NivelCode.GDVida_95952Objects2.length = 0;
gdjs.NivelCode.GDVida_95952Objects3.length = 0;
gdjs.NivelCode.GDVida_95952Objects4.length = 0;
gdjs.NivelCode.GDVida_95953Objects1.length = 0;
gdjs.NivelCode.GDVida_95953Objects2.length = 0;
gdjs.NivelCode.GDVida_95953Objects3.length = 0;
gdjs.NivelCode.GDVida_95953Objects4.length = 0;
gdjs.NivelCode.GDVida_95954Objects1.length = 0;
gdjs.NivelCode.GDVida_95954Objects2.length = 0;
gdjs.NivelCode.GDVida_95954Objects3.length = 0;
gdjs.NivelCode.GDVida_95954Objects4.length = 0;
gdjs.NivelCode.GDVida_95955Objects1.length = 0;
gdjs.NivelCode.GDVida_95955Objects2.length = 0;
gdjs.NivelCode.GDVida_95955Objects3.length = 0;
gdjs.NivelCode.GDVida_95955Objects4.length = 0;
gdjs.NivelCode.GDHUMAObjects1.length = 0;
gdjs.NivelCode.GDHUMAObjects2.length = 0;
gdjs.NivelCode.GDHUMAObjects3.length = 0;
gdjs.NivelCode.GDHUMAObjects4.length = 0;
gdjs.NivelCode.GDLATAObjects1.length = 0;
gdjs.NivelCode.GDLATAObjects2.length = 0;
gdjs.NivelCode.GDLATAObjects3.length = 0;
gdjs.NivelCode.GDLATAObjects4.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects3.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects4.length = 0;
gdjs.NivelCode.GDenemy2Objects1.length = 0;
gdjs.NivelCode.GDenemy2Objects2.length = 0;
gdjs.NivelCode.GDenemy2Objects3.length = 0;
gdjs.NivelCode.GDenemy2Objects4.length = 0;
gdjs.NivelCode.GDenemy3Objects1.length = 0;
gdjs.NivelCode.GDenemy3Objects2.length = 0;
gdjs.NivelCode.GDenemy3Objects3.length = 0;
gdjs.NivelCode.GDenemy3Objects4.length = 0;
gdjs.NivelCode.GDPuruObjects1.length = 0;
gdjs.NivelCode.GDPuruObjects2.length = 0;
gdjs.NivelCode.GDPuruObjects3.length = 0;
gdjs.NivelCode.GDPuruObjects4.length = 0;
gdjs.NivelCode.GDpinchosObjects1.length = 0;
gdjs.NivelCode.GDpinchosObjects2.length = 0;
gdjs.NivelCode.GDpinchosObjects3.length = 0;
gdjs.NivelCode.GDpinchosObjects4.length = 0;
gdjs.NivelCode.GDproyectilObjects1.length = 0;
gdjs.NivelCode.GDproyectilObjects2.length = 0;
gdjs.NivelCode.GDproyectilObjects3.length = 0;
gdjs.NivelCode.GDproyectilObjects4.length = 0;
gdjs.NivelCode.GDHitParticlesObjects1.length = 0;
gdjs.NivelCode.GDHitParticlesObjects2.length = 0;
gdjs.NivelCode.GDHitParticlesObjects3.length = 0;
gdjs.NivelCode.GDHitParticlesObjects4.length = 0;
gdjs.NivelCode.GDhumanoObjects1.length = 0;
gdjs.NivelCode.GDhumanoObjects2.length = 0;
gdjs.NivelCode.GDhumanoObjects3.length = 0;
gdjs.NivelCode.GDhumanoObjects4.length = 0;
gdjs.NivelCode.GDbarreraObjects1.length = 0;
gdjs.NivelCode.GDbarreraObjects2.length = 0;
gdjs.NivelCode.GDbarreraObjects3.length = 0;
gdjs.NivelCode.GDbarreraObjects4.length = 0;
gdjs.NivelCode.GDNewSprite2Objects1.length = 0;
gdjs.NivelCode.GDNewSprite2Objects2.length = 0;
gdjs.NivelCode.GDNewSprite2Objects3.length = 0;
gdjs.NivelCode.GDNewSprite2Objects4.length = 0;
gdjs.NivelCode.GDNewSprite3Objects1.length = 0;
gdjs.NivelCode.GDNewSprite3Objects2.length = 0;
gdjs.NivelCode.GDNewSprite3Objects3.length = 0;
gdjs.NivelCode.GDNewSprite3Objects4.length = 0;
gdjs.NivelCode.GDNewSprite4Objects1.length = 0;
gdjs.NivelCode.GDNewSprite4Objects2.length = 0;
gdjs.NivelCode.GDNewSprite4Objects3.length = 0;
gdjs.NivelCode.GDNewSprite4Objects4.length = 0;
gdjs.NivelCode.GDNewSprite5Objects1.length = 0;
gdjs.NivelCode.GDNewSprite5Objects2.length = 0;
gdjs.NivelCode.GDNewSprite5Objects3.length = 0;
gdjs.NivelCode.GDNewSprite5Objects4.length = 0;
gdjs.NivelCode.GDNewSprite6Objects1.length = 0;
gdjs.NivelCode.GDNewSprite6Objects2.length = 0;
gdjs.NivelCode.GDNewSprite6Objects3.length = 0;
gdjs.NivelCode.GDNewSprite6Objects4.length = 0;
gdjs.NivelCode.GDNewSprite7Objects1.length = 0;
gdjs.NivelCode.GDNewSprite7Objects2.length = 0;
gdjs.NivelCode.GDNewSprite7Objects3.length = 0;
gdjs.NivelCode.GDNewSprite7Objects4.length = 0;
gdjs.NivelCode.GDNewSprite8Objects1.length = 0;
gdjs.NivelCode.GDNewSprite8Objects2.length = 0;
gdjs.NivelCode.GDNewSprite8Objects3.length = 0;
gdjs.NivelCode.GDNewSprite8Objects4.length = 0;
gdjs.NivelCode.GDNewSprite9Objects1.length = 0;
gdjs.NivelCode.GDNewSprite9Objects2.length = 0;
gdjs.NivelCode.GDNewSprite9Objects3.length = 0;
gdjs.NivelCode.GDNewSprite9Objects4.length = 0;
gdjs.NivelCode.GDNewSprite10Objects1.length = 0;
gdjs.NivelCode.GDNewSprite10Objects2.length = 0;
gdjs.NivelCode.GDNewSprite10Objects3.length = 0;
gdjs.NivelCode.GDNewSprite10Objects4.length = 0;
gdjs.NivelCode.GDNewSprite11Objects1.length = 0;
gdjs.NivelCode.GDNewSprite11Objects2.length = 0;
gdjs.NivelCode.GDNewSprite11Objects3.length = 0;
gdjs.NivelCode.GDNewSprite11Objects4.length = 0;
gdjs.NivelCode.GDNewSprite12Objects1.length = 0;
gdjs.NivelCode.GDNewSprite12Objects2.length = 0;
gdjs.NivelCode.GDNewSprite12Objects3.length = 0;
gdjs.NivelCode.GDNewSprite12Objects4.length = 0;
gdjs.NivelCode.GDNewSprite13Objects1.length = 0;
gdjs.NivelCode.GDNewSprite13Objects2.length = 0;
gdjs.NivelCode.GDNewSprite13Objects3.length = 0;
gdjs.NivelCode.GDNewSprite13Objects4.length = 0;
gdjs.NivelCode.GDNewSprite14Objects1.length = 0;
gdjs.NivelCode.GDNewSprite14Objects2.length = 0;
gdjs.NivelCode.GDNewSprite14Objects3.length = 0;
gdjs.NivelCode.GDNewSprite14Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects4.length = 0;
gdjs.NivelCode.GDNewSprite15Objects1.length = 0;
gdjs.NivelCode.GDNewSprite15Objects2.length = 0;
gdjs.NivelCode.GDNewSprite15Objects3.length = 0;
gdjs.NivelCode.GDNewSprite15Objects4.length = 0;
gdjs.NivelCode.GDNewSprite16Objects1.length = 0;
gdjs.NivelCode.GDNewSprite16Objects2.length = 0;
gdjs.NivelCode.GDNewSprite16Objects3.length = 0;
gdjs.NivelCode.GDNewSprite16Objects4.length = 0;
gdjs.NivelCode.GDNewSprite17Objects1.length = 0;
gdjs.NivelCode.GDNewSprite17Objects2.length = 0;
gdjs.NivelCode.GDNewSprite17Objects3.length = 0;
gdjs.NivelCode.GDNewSprite17Objects4.length = 0;
gdjs.NivelCode.GDNewSprite18Objects1.length = 0;
gdjs.NivelCode.GDNewSprite18Objects2.length = 0;
gdjs.NivelCode.GDNewSprite18Objects3.length = 0;
gdjs.NivelCode.GDNewSprite18Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects4.length = 0;
gdjs.NivelCode.GDNewSprite19Objects1.length = 0;
gdjs.NivelCode.GDNewSprite19Objects2.length = 0;
gdjs.NivelCode.GDNewSprite19Objects3.length = 0;
gdjs.NivelCode.GDNewSprite19Objects4.length = 0;
gdjs.NivelCode.GDNewSprite20Objects1.length = 0;
gdjs.NivelCode.GDNewSprite20Objects2.length = 0;
gdjs.NivelCode.GDNewSprite20Objects3.length = 0;
gdjs.NivelCode.GDNewSprite20Objects4.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects1.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects2.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects3.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects4.length = 0;
gdjs.NivelCode.GDbase1Objects1.length = 0;
gdjs.NivelCode.GDbase1Objects2.length = 0;
gdjs.NivelCode.GDbase1Objects3.length = 0;
gdjs.NivelCode.GDbase1Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects4.length = 0;
gdjs.NivelCode.GDpiedrasoObjects1.length = 0;
gdjs.NivelCode.GDpiedrasoObjects2.length = 0;
gdjs.NivelCode.GDpiedrasoObjects3.length = 0;
gdjs.NivelCode.GDpiedrasoObjects4.length = 0;
gdjs.NivelCode.GDpiedraObjects1.length = 0;
gdjs.NivelCode.GDpiedraObjects2.length = 0;
gdjs.NivelCode.GDpiedraObjects3.length = 0;
gdjs.NivelCode.GDpiedraObjects4.length = 0;
gdjs.NivelCode.GDcheckObjects1.length = 0;
gdjs.NivelCode.GDcheckObjects2.length = 0;
gdjs.NivelCode.GDcheckObjects3.length = 0;
gdjs.NivelCode.GDcheckObjects4.length = 0;
gdjs.NivelCode.GDTrofeoObjects1.length = 0;
gdjs.NivelCode.GDTrofeoObjects2.length = 0;
gdjs.NivelCode.GDTrofeoObjects3.length = 0;
gdjs.NivelCode.GDTrofeoObjects4.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects1.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects2.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects3.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects4.length = 0;
gdjs.NivelCode.GDJumpButtonObjects1.length = 0;
gdjs.NivelCode.GDJumpButtonObjects2.length = 0;
gdjs.NivelCode.GDJumpButtonObjects3.length = 0;
gdjs.NivelCode.GDJumpButtonObjects4.length = 0;
gdjs.NivelCode.GDinicioObjects1.length = 0;
gdjs.NivelCode.GDinicioObjects2.length = 0;
gdjs.NivelCode.GDinicioObjects3.length = 0;
gdjs.NivelCode.GDinicioObjects4.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects1.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects2.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects3.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects4.length = 0;
gdjs.NivelCode.GDNewSprite21Objects1.length = 0;
gdjs.NivelCode.GDNewSprite21Objects2.length = 0;
gdjs.NivelCode.GDNewSprite21Objects3.length = 0;
gdjs.NivelCode.GDNewSprite21Objects4.length = 0;
gdjs.NivelCode.GDflecahasObjects1.length = 0;
gdjs.NivelCode.GDflecahasObjects2.length = 0;
gdjs.NivelCode.GDflecahasObjects3.length = 0;
gdjs.NivelCode.GDflecahasObjects4.length = 0;
gdjs.NivelCode.GDspaceObjects1.length = 0;
gdjs.NivelCode.GDspaceObjects2.length = 0;
gdjs.NivelCode.GDspaceObjects3.length = 0;
gdjs.NivelCode.GDspaceObjects4.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects1.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects2.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects3.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects4.length = 0;
gdjs.NivelCode.GDNewSprite22Objects1.length = 0;
gdjs.NivelCode.GDNewSprite22Objects2.length = 0;
gdjs.NivelCode.GDNewSprite22Objects3.length = 0;
gdjs.NivelCode.GDNewSprite22Objects4.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects1.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects2.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects3.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects4.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects1.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects2.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects3.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects4.length = 0;

gdjs.NivelCode.eventsList28(runtimeScene);
gdjs.NivelCode.GDM_95225scara_9595HumaObjects1.length = 0;
gdjs.NivelCode.GDM_95225scara_9595HumaObjects2.length = 0;
gdjs.NivelCode.GDM_95225scara_9595HumaObjects3.length = 0;
gdjs.NivelCode.GDM_95225scara_9595HumaObjects4.length = 0;
gdjs.NivelCode.GDbackgroundObjects1.length = 0;
gdjs.NivelCode.GDbackgroundObjects2.length = 0;
gdjs.NivelCode.GDbackgroundObjects3.length = 0;
gdjs.NivelCode.GDbackgroundObjects4.length = 0;
gdjs.NivelCode.GDNewSpriteObjects1.length = 0;
gdjs.NivelCode.GDNewSpriteObjects2.length = 0;
gdjs.NivelCode.GDNewSpriteObjects3.length = 0;
gdjs.NivelCode.GDNewSpriteObjects4.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects1.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects2.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects3.length = 0;
gdjs.NivelCode.GDM_95225scara_9595LataObjects4.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects1.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects2.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects3.length = 0;
gdjs.NivelCode.GDM_95225scara_9595CuriquingueObjects4.length = 0;
gdjs.NivelCode.GDSamiObjects1.length = 0;
gdjs.NivelCode.GDSamiObjects2.length = 0;
gdjs.NivelCode.GDSamiObjects3.length = 0;
gdjs.NivelCode.GDSamiObjects4.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.NivelCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.NivelCode.GDVida_95951Objects1.length = 0;
gdjs.NivelCode.GDVida_95951Objects2.length = 0;
gdjs.NivelCode.GDVida_95951Objects3.length = 0;
gdjs.NivelCode.GDVida_95951Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite2Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite3Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite4Objects4.length = 0;
gdjs.NivelCode.GDenemy1Objects1.length = 0;
gdjs.NivelCode.GDenemy1Objects2.length = 0;
gdjs.NivelCode.GDenemy1Objects3.length = 0;
gdjs.NivelCode.GDenemy1Objects4.length = 0;
gdjs.NivelCode.GDVida_95952Objects1.length = 0;
gdjs.NivelCode.GDVida_95952Objects2.length = 0;
gdjs.NivelCode.GDVida_95952Objects3.length = 0;
gdjs.NivelCode.GDVida_95952Objects4.length = 0;
gdjs.NivelCode.GDVida_95953Objects1.length = 0;
gdjs.NivelCode.GDVida_95953Objects2.length = 0;
gdjs.NivelCode.GDVida_95953Objects3.length = 0;
gdjs.NivelCode.GDVida_95953Objects4.length = 0;
gdjs.NivelCode.GDVida_95954Objects1.length = 0;
gdjs.NivelCode.GDVida_95954Objects2.length = 0;
gdjs.NivelCode.GDVida_95954Objects3.length = 0;
gdjs.NivelCode.GDVida_95954Objects4.length = 0;
gdjs.NivelCode.GDVida_95955Objects1.length = 0;
gdjs.NivelCode.GDVida_95955Objects2.length = 0;
gdjs.NivelCode.GDVida_95955Objects3.length = 0;
gdjs.NivelCode.GDVida_95955Objects4.length = 0;
gdjs.NivelCode.GDHUMAObjects1.length = 0;
gdjs.NivelCode.GDHUMAObjects2.length = 0;
gdjs.NivelCode.GDHUMAObjects3.length = 0;
gdjs.NivelCode.GDHUMAObjects4.length = 0;
gdjs.NivelCode.GDLATAObjects1.length = 0;
gdjs.NivelCode.GDLATAObjects2.length = 0;
gdjs.NivelCode.GDLATAObjects3.length = 0;
gdjs.NivelCode.GDLATAObjects4.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects1.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects2.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects3.length = 0;
gdjs.NivelCode.GDCURIQUINGUEObjects4.length = 0;
gdjs.NivelCode.GDenemy2Objects1.length = 0;
gdjs.NivelCode.GDenemy2Objects2.length = 0;
gdjs.NivelCode.GDenemy2Objects3.length = 0;
gdjs.NivelCode.GDenemy2Objects4.length = 0;
gdjs.NivelCode.GDenemy3Objects1.length = 0;
gdjs.NivelCode.GDenemy3Objects2.length = 0;
gdjs.NivelCode.GDenemy3Objects3.length = 0;
gdjs.NivelCode.GDenemy3Objects4.length = 0;
gdjs.NivelCode.GDPuruObjects1.length = 0;
gdjs.NivelCode.GDPuruObjects2.length = 0;
gdjs.NivelCode.GDPuruObjects3.length = 0;
gdjs.NivelCode.GDPuruObjects4.length = 0;
gdjs.NivelCode.GDpinchosObjects1.length = 0;
gdjs.NivelCode.GDpinchosObjects2.length = 0;
gdjs.NivelCode.GDpinchosObjects3.length = 0;
gdjs.NivelCode.GDpinchosObjects4.length = 0;
gdjs.NivelCode.GDproyectilObjects1.length = 0;
gdjs.NivelCode.GDproyectilObjects2.length = 0;
gdjs.NivelCode.GDproyectilObjects3.length = 0;
gdjs.NivelCode.GDproyectilObjects4.length = 0;
gdjs.NivelCode.GDHitParticlesObjects1.length = 0;
gdjs.NivelCode.GDHitParticlesObjects2.length = 0;
gdjs.NivelCode.GDHitParticlesObjects3.length = 0;
gdjs.NivelCode.GDHitParticlesObjects4.length = 0;
gdjs.NivelCode.GDhumanoObjects1.length = 0;
gdjs.NivelCode.GDhumanoObjects2.length = 0;
gdjs.NivelCode.GDhumanoObjects3.length = 0;
gdjs.NivelCode.GDhumanoObjects4.length = 0;
gdjs.NivelCode.GDbarreraObjects1.length = 0;
gdjs.NivelCode.GDbarreraObjects2.length = 0;
gdjs.NivelCode.GDbarreraObjects3.length = 0;
gdjs.NivelCode.GDbarreraObjects4.length = 0;
gdjs.NivelCode.GDNewSprite2Objects1.length = 0;
gdjs.NivelCode.GDNewSprite2Objects2.length = 0;
gdjs.NivelCode.GDNewSprite2Objects3.length = 0;
gdjs.NivelCode.GDNewSprite2Objects4.length = 0;
gdjs.NivelCode.GDNewSprite3Objects1.length = 0;
gdjs.NivelCode.GDNewSprite3Objects2.length = 0;
gdjs.NivelCode.GDNewSprite3Objects3.length = 0;
gdjs.NivelCode.GDNewSprite3Objects4.length = 0;
gdjs.NivelCode.GDNewSprite4Objects1.length = 0;
gdjs.NivelCode.GDNewSprite4Objects2.length = 0;
gdjs.NivelCode.GDNewSprite4Objects3.length = 0;
gdjs.NivelCode.GDNewSprite4Objects4.length = 0;
gdjs.NivelCode.GDNewSprite5Objects1.length = 0;
gdjs.NivelCode.GDNewSprite5Objects2.length = 0;
gdjs.NivelCode.GDNewSprite5Objects3.length = 0;
gdjs.NivelCode.GDNewSprite5Objects4.length = 0;
gdjs.NivelCode.GDNewSprite6Objects1.length = 0;
gdjs.NivelCode.GDNewSprite6Objects2.length = 0;
gdjs.NivelCode.GDNewSprite6Objects3.length = 0;
gdjs.NivelCode.GDNewSprite6Objects4.length = 0;
gdjs.NivelCode.GDNewSprite7Objects1.length = 0;
gdjs.NivelCode.GDNewSprite7Objects2.length = 0;
gdjs.NivelCode.GDNewSprite7Objects3.length = 0;
gdjs.NivelCode.GDNewSprite7Objects4.length = 0;
gdjs.NivelCode.GDNewSprite8Objects1.length = 0;
gdjs.NivelCode.GDNewSprite8Objects2.length = 0;
gdjs.NivelCode.GDNewSprite8Objects3.length = 0;
gdjs.NivelCode.GDNewSprite8Objects4.length = 0;
gdjs.NivelCode.GDNewSprite9Objects1.length = 0;
gdjs.NivelCode.GDNewSprite9Objects2.length = 0;
gdjs.NivelCode.GDNewSprite9Objects3.length = 0;
gdjs.NivelCode.GDNewSprite9Objects4.length = 0;
gdjs.NivelCode.GDNewSprite10Objects1.length = 0;
gdjs.NivelCode.GDNewSprite10Objects2.length = 0;
gdjs.NivelCode.GDNewSprite10Objects3.length = 0;
gdjs.NivelCode.GDNewSprite10Objects4.length = 0;
gdjs.NivelCode.GDNewSprite11Objects1.length = 0;
gdjs.NivelCode.GDNewSprite11Objects2.length = 0;
gdjs.NivelCode.GDNewSprite11Objects3.length = 0;
gdjs.NivelCode.GDNewSprite11Objects4.length = 0;
gdjs.NivelCode.GDNewSprite12Objects1.length = 0;
gdjs.NivelCode.GDNewSprite12Objects2.length = 0;
gdjs.NivelCode.GDNewSprite12Objects3.length = 0;
gdjs.NivelCode.GDNewSprite12Objects4.length = 0;
gdjs.NivelCode.GDNewSprite13Objects1.length = 0;
gdjs.NivelCode.GDNewSprite13Objects2.length = 0;
gdjs.NivelCode.GDNewSprite13Objects3.length = 0;
gdjs.NivelCode.GDNewSprite13Objects4.length = 0;
gdjs.NivelCode.GDNewSprite14Objects1.length = 0;
gdjs.NivelCode.GDNewSprite14Objects2.length = 0;
gdjs.NivelCode.GDNewSprite14Objects3.length = 0;
gdjs.NivelCode.GDNewSprite14Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite6Objects4.length = 0;
gdjs.NivelCode.GDNewSprite15Objects1.length = 0;
gdjs.NivelCode.GDNewSprite15Objects2.length = 0;
gdjs.NivelCode.GDNewSprite15Objects3.length = 0;
gdjs.NivelCode.GDNewSprite15Objects4.length = 0;
gdjs.NivelCode.GDNewSprite16Objects1.length = 0;
gdjs.NivelCode.GDNewSprite16Objects2.length = 0;
gdjs.NivelCode.GDNewSprite16Objects3.length = 0;
gdjs.NivelCode.GDNewSprite16Objects4.length = 0;
gdjs.NivelCode.GDNewSprite17Objects1.length = 0;
gdjs.NivelCode.GDNewSprite17Objects2.length = 0;
gdjs.NivelCode.GDNewSprite17Objects3.length = 0;
gdjs.NivelCode.GDNewSprite17Objects4.length = 0;
gdjs.NivelCode.GDNewSprite18Objects1.length = 0;
gdjs.NivelCode.GDNewSprite18Objects2.length = 0;
gdjs.NivelCode.GDNewSprite18Objects3.length = 0;
gdjs.NivelCode.GDNewSprite18Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite7Objects4.length = 0;
gdjs.NivelCode.GDNewSprite19Objects1.length = 0;
gdjs.NivelCode.GDNewSprite19Objects2.length = 0;
gdjs.NivelCode.GDNewSprite19Objects3.length = 0;
gdjs.NivelCode.GDNewSprite19Objects4.length = 0;
gdjs.NivelCode.GDNewSprite20Objects1.length = 0;
gdjs.NivelCode.GDNewSprite20Objects2.length = 0;
gdjs.NivelCode.GDNewSprite20Objects3.length = 0;
gdjs.NivelCode.GDNewSprite20Objects4.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects1.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects2.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects3.length = 0;
gdjs.NivelCode.GDproyectil_9595jugadorObjects4.length = 0;
gdjs.NivelCode.GDbase1Objects1.length = 0;
gdjs.NivelCode.GDbase1Objects2.length = 0;
gdjs.NivelCode.GDbase1Objects3.length = 0;
gdjs.NivelCode.GDbase1Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite5Objects4.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects1.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects2.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects3.length = 0;
gdjs.NivelCode.GDNewTiledSprite8Objects4.length = 0;
gdjs.NivelCode.GDpiedrasoObjects1.length = 0;
gdjs.NivelCode.GDpiedrasoObjects2.length = 0;
gdjs.NivelCode.GDpiedrasoObjects3.length = 0;
gdjs.NivelCode.GDpiedrasoObjects4.length = 0;
gdjs.NivelCode.GDpiedraObjects1.length = 0;
gdjs.NivelCode.GDpiedraObjects2.length = 0;
gdjs.NivelCode.GDpiedraObjects3.length = 0;
gdjs.NivelCode.GDpiedraObjects4.length = 0;
gdjs.NivelCode.GDcheckObjects1.length = 0;
gdjs.NivelCode.GDcheckObjects2.length = 0;
gdjs.NivelCode.GDcheckObjects3.length = 0;
gdjs.NivelCode.GDcheckObjects4.length = 0;
gdjs.NivelCode.GDTrofeoObjects1.length = 0;
gdjs.NivelCode.GDTrofeoObjects2.length = 0;
gdjs.NivelCode.GDTrofeoObjects3.length = 0;
gdjs.NivelCode.GDTrofeoObjects4.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects1.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects2.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects3.length = 0;
gdjs.NivelCode.GDMobileJoystickObjects4.length = 0;
gdjs.NivelCode.GDJumpButtonObjects1.length = 0;
gdjs.NivelCode.GDJumpButtonObjects2.length = 0;
gdjs.NivelCode.GDJumpButtonObjects3.length = 0;
gdjs.NivelCode.GDJumpButtonObjects4.length = 0;
gdjs.NivelCode.GDinicioObjects1.length = 0;
gdjs.NivelCode.GDinicioObjects2.length = 0;
gdjs.NivelCode.GDinicioObjects3.length = 0;
gdjs.NivelCode.GDinicioObjects4.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects1.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects2.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects3.length = 0;
gdjs.NivelCode.GDdiablo_9595de_9595lataObjects4.length = 0;
gdjs.NivelCode.GDNewSprite21Objects1.length = 0;
gdjs.NivelCode.GDNewSprite21Objects2.length = 0;
gdjs.NivelCode.GDNewSprite21Objects3.length = 0;
gdjs.NivelCode.GDNewSprite21Objects4.length = 0;
gdjs.NivelCode.GDflecahasObjects1.length = 0;
gdjs.NivelCode.GDflecahasObjects2.length = 0;
gdjs.NivelCode.GDflecahasObjects3.length = 0;
gdjs.NivelCode.GDflecahasObjects4.length = 0;
gdjs.NivelCode.GDspaceObjects1.length = 0;
gdjs.NivelCode.GDspaceObjects2.length = 0;
gdjs.NivelCode.GDspaceObjects3.length = 0;
gdjs.NivelCode.GDspaceObjects4.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects1.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects2.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects3.length = 0;
gdjs.NivelCode.GDLetra_9595QObjects4.length = 0;
gdjs.NivelCode.GDNewSprite22Objects1.length = 0;
gdjs.NivelCode.GDNewSprite22Objects2.length = 0;
gdjs.NivelCode.GDNewSprite22Objects3.length = 0;
gdjs.NivelCode.GDNewSprite22Objects4.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects1.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects2.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects3.length = 0;
gdjs.NivelCode.GDcuriquingue_9595letrasObjects4.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects1.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects2.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects3.length = 0;
gdjs.NivelCode.GDHaya_9595humaObjects4.length = 0;


return;

}

gdjs['NivelCode'] = gdjs.NivelCode;
